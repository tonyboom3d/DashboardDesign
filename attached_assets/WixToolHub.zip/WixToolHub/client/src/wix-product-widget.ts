import { initWixApiClient } from "./lib/wix-api-client";
import { getAppInstance } from "./lib/wix-sdk";

// This script will be loaded in the Wix product page
(function () {
  try {
    // Get the instance ID from the URL
    const instanceId = getAppInstance();

    if (!instanceId) {
      console.error("No instance ID found");
      return;
    }

    // Initialize the Wix API client
    const client = initWixApiClient(instanceId);

    // Create container for our widget
    const container = document.createElement("div");
    container.id = "shipping-bar-product-widget";
    container.style.padding = "10px";
    container.style.marginTop = "15px";
    container.style.border = "1px solid #e5e7eb";
    container.style.borderRadius = "8px";

    // Insert the container into the page
    document.currentScript?.parentNode?.insertBefore(
      container,
      document.currentScript,
    );

    // Fetch settings and render widget
    client
      .getUserSettings()
      .then((response) => {
        const settings = response.currentUserSettings;

        if (!settings || !settings.enabled) {
          container.style.display = "none";
          return;
        }

        // Create content based on settings
        renderWidget(container, settings);
      })
      .catch((error) => {
        console.error("Error fetching settings:", error);
        container.style.display = "none";
      });
  } catch (error) {
    console.error("Error initializing widget:", error);
  }
})();

function renderWidget(container: HTMLElement, settings: any) {
  // Calculate remaining amount for free shipping
  const threshold = parseFloat(settings.threshold);

  // Create progress bar
  const barElement = document.createElement("div");
  barElement.style.display = "flex";
  barElement.style.flexDirection = "column";
  barElement.style.gap = "8px";

  // Message text
  const messageElement = document.createElement("div");
  messageElement.style.textAlign = settings.textAlign || "center";
  messageElement.style.color = settings.textColor || "#333";
  messageElement.style.fontWeight = "bold";

  // Default message for product page
  messageElement.textContent = `${settings.iconEmoji || "🎁"} ${settings.threshold}${settings.currencySymbol || "$"} away from FREE SHIPPING!`;

  // Add to container
  barElement.appendChild(messageElement);
  container.appendChild(barElement);
}
