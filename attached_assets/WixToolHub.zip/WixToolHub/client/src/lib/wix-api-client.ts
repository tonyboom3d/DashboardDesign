import { ShippingBarSettings } from "@shared/schema";

const APP_ID = "88ca7de8-1b4f-4407-b171-cb3f5b573c8f"; // App ID ב-Wix
const WIX_BASE_URL = "https://tonyboom3d.wixsite.com/freeshippingbar/_functions/";

class WixApiClient {
  private instanceId: string;
  private apiUrl: string;
  private isDemoMode: boolean = false;

  constructor(instanceId: string) {
    this.instanceId = instanceId;
    this.isDemoMode = instanceId === "demo-instance-12345";

    // משתמשים תמיד ב-WIX_BASE_URL
    this.apiUrl = WIX_BASE_URL;
    console.log("Using API URL:", this.apiUrl);
  }

  async getUserSettings() {
    try {
      if (!this.instanceId) {
        throw new Error("Instance ID not set. Initialize the client first.");
      }

      if (this.isDemoMode) {
        console.log("Using demo settings for embedded mode");
        return this._getDemoSettings();
      }

      // שימוש ב-instanceId כפרמטר
      const apiUrl = `${this.apiUrl}userSettings?instanceId=${this.instanceId}`;
      console.log(`Fetching user settings from: ${apiUrl}`);

      const fetchOptions: RequestInit = {
        method: "GET",
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Cache-Control": "no-cache, no-store, must-revalidate",
        },
        credentials: "include" as RequestCredentials, // הגדרה נכונה עם טיפוס
        mode: "cors" as RequestMode, // הגדרה נכונה עם טיפוס
      };

      console.log(`Initial fetch options: ${JSON.stringify(fetchOptions)}`);

      const response = await fetch(apiUrl, fetchOptions);

      if (response.ok) {
        console.log("CORS fetch successful!");
        return await response.json();
      } else {
        console.warn(`Server responded with status: ${response.status}`);
        throw new Error(`Server responded with status: ${response.status}`);
      }
    } catch (error) {
      console.error("Error fetching user settings:", error);
      console.log("Falling back to demo settings due to error");
      return this._getDemoSettings();
    }
  }

  private _getDemoSettings() {
    return {
      currentUserSettings: {
        enabled: true,
        status: "active",
        usage: 0,
        currentPlan: "free",
        resetDate: new Date().toISOString(),
        maxUsed: 0,
        fullUserSettings: {
          threshold: "100",
          enabled: true,
          barStyle: "gradient",
          barColor: "#4f46e5",
          progressBgColor: "#E0E0E0",
          backgroundColor: "#F5F5F5",
          borderColor: "#E0E0E0",
          borderThickness: 1,
          textColor: "#000000",
          accentColor: "#FF5722",
          barText: "${remaining} עד משלוח חינם!",
          successText: "🎉 מזל טוב! אתה זכאי למשלוח חינם!",
          currencyCode: "ILS",
          currencySymbol: "₪",
          textDirection: "rtl",
          position: "top",
          showOnProduct: true,
          showOnCart: true,
        },
      },
    };
  }

  async updateSettings(settings: Partial<ShippingBarSettings>) {
    try {
      if (!this.instanceId) {
        throw new Error("Instance ID not set. Initialize the client first.");
      }

      // המרת האובייקט לפרמטרים ב-URL
      const queryParams = new URLSearchParams();
      Object.entries(settings).forEach(([key, value]) => {
        queryParams.append(key, String(value));
      });
      queryParams.append('_', Date.now().toString()); // מניעת caching

      const response = await fetch(`${this.apiUrl}/updateSettings/${this.instanceId}?${queryParams.toString()}`, {
        method: "GET",
        headers: {
          "Accept": "application/json",
          "x-merchant-id": this.instanceId,
        },
        credentials: "include" as RequestCredentials,
        mode: "cors" as RequestMode,
      });

      if (!response.ok) {
        throw new Error(`Failed to update settings: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error("Error updating settings:", error);
      throw error;
    }
  }
}

let _wixApiClient: WixApiClient | null = null;

export function initWixApiClient(instanceId: string) {
  console.log("Initializing WixApiClient with instanceId:", instanceId);
  _wixApiClient = new WixApiClient(instanceId);
  return _wixApiClient;
}

export function getWixApiClient() {
  if (!_wixApiClient) {
    throw new Error("WixApiClient not initialized. Call initWixApiClient first.");
  }
  return _wixApiClient;
}

export function isInitialized(): boolean {
  return _wixApiClient !== null;
}