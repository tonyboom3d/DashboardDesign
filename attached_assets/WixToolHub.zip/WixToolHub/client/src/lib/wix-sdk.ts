import { Cart, WixProduct } from '@shared/schema';

/**
 * This file contains functions to interact with the Wix SDK.
 * In a real implementation, we would use the actual Wix SDK methods.
 * For this demo, we'll create mock functions that simulate the behavior.
 */

let mockCart: Cart = {
  items: [
    {
      productId: "product-1",
      title: "Premium Headphones",
      price: 39.99,
      quantity: 1,
      imageUrl: "https://images.unsplash.com/photo-1560343090-f0409e92791a?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80"
    },
    {
      productId: "product-2",
      title: "Running Shoes",
      price: 89.95,
      quantity: 1,
      imageUrl: "https://images.unsplash.com/photo-1491553895911-0055eca6402d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80"
    },
    {
      productId: "product-3",
      title: "Cotton T-Shirt",
      price: 10.05,
      quantity: 1,
      imageUrl: "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80"
    }
  ],
  total: 139.99
};

// Initialize the Wix SDK
export const initWixSDK = () => {
  console.log('Initializing Wix SDK...');
  
  // In a real implementation, we would initialize the Wix SDK here
  // For example:
  // const Wix = window.Wix;
  // Wix.init({ components: ['Stores'] });
};

// Get the cart data
export const getCart = async (): Promise<Cart> => {
  // In a real implementation, we would use the Wix SDK to get the cart data
  // For example:
  // const cartData = await Wix.Stores.getCurrentCart();
  
  return mockCart;
};

// Add an item to the cart
export const addItemToCart = async (productId: string, quantity: number = 1): Promise<Cart> => {
  // In a real implementation, we would use the Wix SDK to add an item to the cart
  // For example:
  // await Wix.Stores.addToCart({
  //   product: { id: productId },
  //   quantity
  // });
  
  const response = await fetch('/api/demo/products');
  const products: WixProduct[] = await response.json();
  
  const product = products.find(p => p.id === productId);
  
  if (product) {
    // Check if product already in cart
    const existingItemIndex = mockCart.items.findIndex(item => item.productId === productId);
    
    if (existingItemIndex >= 0) {
      // Update existing item
      mockCart.items[existingItemIndex].quantity += quantity;
    } else {
      // Add new item
      mockCart.items.push({
        productId,
        title: product.title,
        price: product.price,
        quantity,
        imageUrl: product.imageUrl
      });
    }
    
    // Recalculate total
    mockCart.total = mockCart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }
  
  return mockCart;
};

// Remove an item from the cart
export const removeItemFromCart = async (productId: string): Promise<Cart> => {
  // In a real implementation, we would use the Wix SDK to remove an item from the cart
  // For example:
  // await Wix.Stores.removeFromCart({ cartItemId: productId });
  
  const existingItemIndex = mockCart.items.findIndex(item => item.productId === productId);
  
  if (existingItemIndex >= 0) {
    mockCart.items.splice(existingItemIndex, 1);
    
    // Recalculate total
    mockCart.total = mockCart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }
  
  return mockCart;
};

// Update item quantity in the cart
export const updateItemQuantity = async (productId: string, quantity: number): Promise<Cart> => {
  // In a real implementation, we would use the Wix SDK to update item quantity
  // For example:
  // await Wix.Stores.updateCartItemQuantity({
  //   cartItemId: productId,
  //   quantity
  // });
  
  const existingItemIndex = mockCart.items.findIndex(item => item.productId === productId);
  
  if (existingItemIndex >= 0) {
    mockCart.items[existingItemIndex].quantity = quantity;
    
    // Recalculate total
    mockCart.total = mockCart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }
  
  return mockCart;
};

// Get store products
export const getStoreProducts = async (): Promise<WixProduct[]> => {
  // In a real implementation, we would use the Wix SDK to get store products
  // For example:
  // const products = await Wix.Stores.getProducts();
  
  const response = await fetch('/api/demo/products');
  return response.json();
};
import { Buffer } from 'buffer';
import { createHmac } from 'crypto';

export function getAppInstance() {
  return new URLSearchParams(window.location.search).get('instance') || null;
}

export function parseInstance(instance: string, appSecret: string) {
  const parts = instance.split('.');
  const hash = parts[0];
  const payload = parts[1];
  
  if (!payload) {
    return null;
  }
  
  if (!validateInstance(hash, payload, appSecret)) {
    throw new Error('Invalid instance');
  }
  
  return JSON.parse(Buffer.from(payload, 'base64').toString('utf8'));
}

function validateInstance(hash: string, payload: string, secret: string) {
  const signedHash = createHmac('sha256', secret)
    .update(payload)
    .digest('base64');
  return hash === signedHash;
}
