
// Demo settings for testing in Wix dashboard
export const getDemoSettings = () => {
  // Use default demo settings
  return {
    currentUserSettings: {
      enabled: true,
      usage: 0,
      currentPlan: "Free",
      resetDate: "2025-03-15T10:54:44.654Z",
      fullUserSettings: {
        showOnMobileCart: true,
        barStyle: "gradient",
        successText: "🎉 מזל טוב! אתה זכאי למשלוח חינם!",
        backgroundColor: "#F5F5F5",
        showOnDesktop: true,
        showOnProduct: true,
        viewCount: 128,
        borderThickness: 1,
        currencySymbol: "₪",
        showOnMobile: true,
        showOnDesktopMiniCart: true,
        enabled: true,
        textColor: "#000000",
        showOnMobileMiniCart: true,
        showOnMobileProduct: true,
        showOnMiniCart: true,
        buttonText: "הוסף לסל",
        showOnDesktopHeader: true,
        textAlign: "right",
        textDirection: "rtl",
        threshold: 199,
        barColor: "#4CAF50",
        borderColor: "#E0E0E0"
      }
    }
  };
};
