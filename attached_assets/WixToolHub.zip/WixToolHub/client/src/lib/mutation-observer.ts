/**
 * Utility for using MutationObserver to watch for DOM changes and inject
 * our shipping bar into dynamic elements like the header and mini cart.
 */

import { ShippingBarSettings } from '@shared/schema';

export interface MutationConfig {
  targetSelector: string;
  settings: ShippingBarSettings;
  onMatch: (element: Element) => void;
  observeConfig?: MutationObserverInit;
}

export const createElementObserver = ({
  targetSelector,
  settings,
  onMatch,
  observeConfig = {
    childList: true,
    subtree: true,
    attributes: false,
    characterData: false
  }
}: MutationConfig): MutationObserver | null => {
  // Check if MutationObserver is available
  if (!window.MutationObserver) {
    console.error('MutationObserver is not supported in this browser');
    return null;
  }
  
  // Create observer instance
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      // Check for added nodes
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            // Check if the added node matches our target
            if ((node as Element).matches(targetSelector)) {
              onMatch(node as Element);
            }
            
            // Check if any of the descendants match our target
            const matches = (node as Element).querySelectorAll(targetSelector);
            if (matches.length > 0) {
              matches.forEach(onMatch);
            }
          }
        });
      }
    });
  });
  
  // Start observing
  observer.observe(document.body, observeConfig);
  
  return observer;
};

// Helper function to inject shipping bar into header
export const injectShippingBarToHeader = (settings: ShippingBarSettings) => {
  if (!settings.enabled || !settings.showOnHeader) return;
  
  const headerObserver = createElementObserver({
    targetSelector: 'header, .site-header, [data-wix-header], .header',
    settings,
    onMatch: (element) => {
      console.log('Header element found:', element);
      
      // Check if shipping bar is already injected
      if (element.querySelector('.shipping-bar-header')) return;
      
      // Create shipping bar container
      const shippingBarContainer = document.createElement('div');
      shippingBarContainer.className = 'shipping-bar-header';
      shippingBarContainer.style.backgroundColor = settings.barColor;
      shippingBarContainer.style.color = settings.textColor;
      shippingBarContainer.style.padding = '8px 16px';
      shippingBarContainer.style.textAlign = 'center';
      
      // Add shipping bar content
      // In a real implementation, we would render our React component here
      // For demo purposes, we'll just add placeholder HTML
      shippingBarContainer.innerHTML = `
        <div class="shipping-bar-progress" style="height: 4px; background: rgba(255,255,255,0.3); border-radius: 2px; margin-bottom: 4px;">
          <div style="height: 100%; width: 70%; background: #fff; border-radius: 2px;"></div>
        </div>
        <p style="margin: 0; font-size: 14px;">$15 away from FREE SHIPPING!</p>
      `;
      
      // Inject at the top of the header
      element.prepend(shippingBarContainer);
    }
  });
  
  return headerObserver;
};

// Helper function to inject shipping bar into mini cart
export const injectShippingBarToMiniCart = (settings: ShippingBarSettings) => {
  if (!settings.enabled || !settings.showOnMiniCart) return;
  
  const miniCartObserver = createElementObserver({
    targetSelector: '.mini-cart, [data-wix-mini-cart], .cart-dropdown',
    settings,
    onMatch: (element) => {
      console.log('Mini cart element found:', element);
      
      // Check if shipping bar is already injected
      if (element.querySelector('.shipping-bar-mini-cart')) return;
      
      // Create shipping bar container
      const shippingBarContainer = document.createElement('div');
      shippingBarContainer.className = 'shipping-bar-mini-cart';
      shippingBarContainer.style.backgroundColor = settings.backgroundColor;
      shippingBarContainer.style.padding = '8px';
      shippingBarContainer.style.borderBottom = '1px solid #e0e0e0';
      
      // Add shipping bar content
      // In a real implementation, we would render our React component here
      // For demo purposes, we'll just add placeholder HTML
      shippingBarContainer.innerHTML = `
        <div class="shipping-bar-progress" style="height: 4px; background: #fff; border-radius: 2px; margin-bottom: 4px;">
          <div style="height: 100%; width: 70%; background: ${settings.barColor}; border-radius: 2px;"></div>
        </div>
        <p style="margin: 0; font-size: 12px; color: #616161;">$15 away from FREE SHIPPING!</p>
      `;
      
      // Find the appropriate location to inject
      const headerElement = element.querySelector('header, .mini-cart-header, .cart-header');
      
      if (headerElement) {
        headerElement.insertAdjacentElement('afterend', shippingBarContainer);
      } else {
        // If no header found, insert at the beginning
        element.prepend(shippingBarContainer);
      }
    }
  });
  
  return miniCartObserver;
};

// Main function to start DOM observers
export const initDOMObservers = (settings: ShippingBarSettings) => {
  // Inject shipping bar into header
  const headerObserver = injectShippingBarToHeader(settings);
  
  // Inject shipping bar into mini cart
  const miniCartObserver = injectShippingBarToMiniCart(settings);
  
  // Return a cleanup function
  return () => {
    if (headerObserver) headerObserver.disconnect();
    if (miniCartObserver) miniCartObserver.disconnect();
  };
};
