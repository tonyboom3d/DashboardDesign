import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// In production, we would initialize the Wix SDK here
// import { initWixSDK } from "./lib/wix-sdk";
// initWixSDK();

createRoot(document.getElementById("root")!).render(<App />);
