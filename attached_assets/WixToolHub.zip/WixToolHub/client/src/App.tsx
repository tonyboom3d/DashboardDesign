import React, { useEffect, useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import "./App.css";
import SettingsManager from "./components/SettingsManager";
import {
  initWixApiClient,
  isInitialized as isWixApiClientInitialized,
} from "./lib/wix-api-client";
import ErrorBoundary from "./components/ErrorBoundary";

// Create a client
const queryClient = new QueryClient();
function App() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);

  useEffect(() => {
    console.log("========== App.tsx: useEffect triggered ==========");

    const getSafeLocation = () => {
      try {
        return {
          href: window.location.href,
          origin: window.location.origin,
          pathname: window.location.pathname,
          search: window.location.search,
          hash: window.location.hash,
        };
      } catch (error) {
        console.warn("[DEBUG-LOCATION] Failed to access window.location due to cross-origin:", error);
        return null;
      }
    };

    // Improved function to get instanceId from URL
    const getInstanceIdFromUrl = (): string | null => {
      try {
        const urlParams = new URLSearchParams(window.location.search);
        const instanceId = urlParams.get("instanceId");

        if (instanceId) return instanceId;

        // בדיקה אם instanceId נמצא בתוך JWT
        const instanceParam = urlParams.get("instance");
        if (instanceParam) {
          try {
            const payload = JSON.parse(atob(instanceParam.split(".")[1]));
            return payload.instanceId || null;
          } catch (error) {
            console.error("Error decoding JWT:", error);
          }
        }
      } catch (error) {
        console.error("Error retrieving instanceId:", error);
      }
      return null;
    };


    try {
      console.log("[DEBUG-INIT] Checking if WixApiClient is already initialized...");
      // Check if WixApiClient is already initialized
      const alreadyInitialized = isWixApiClientInitialized();
      console.log("[DEBUG-INIT] WixApiClient already initialized:", alreadyInitialized);

      if (!alreadyInitialized) {
        // Get instanceId using improved method
        console.log("[DEBUG-INIT] Getting instanceId from URL...");
        const instanceId = getInstanceIdFromUrl();
        console.log("[DEBUG-INIT] Extracted instanceId result:", instanceId);

        if (instanceId) {
          console.log("[DEBUG-INIT] Initializing WixApiClient with instanceId:", instanceId);
          // Initialize WixApiClient with instanceId
          try {
            const client = initWixApiClient(instanceId);
            console.log("[DEBUG-INIT] WixApiClient initialized successfully:", client ? "client created" : "no client returned");
            console.log("[DEBUG-INIT] Setting isInitialized to true");
            setIsInitialized(true);
          } catch (initErr) {
            console.error("[DEBUG-INIT] Failed to initialize WixApiClient:", initErr);
            setInitError(`Failed to initialize WixApiClient: ${initErr instanceof Error ? initErr.message : String(initErr)}`);
          }
        } else {
          // If no instanceId, display an error message
          console.error("[DEBUG-INIT] No instanceId found in URL");
          setInitError(
            "No instanceId found in URL. Please provide an instanceId parameter.",
          );
        }
      } else {
        console.log("[DEBUG-INIT] WixApiClient already initialized, setting isInitialized to true");
        setIsInitialized(true);
      }
    } catch (error) {
      console.error("[DEBUG-ERROR] Error in App.tsx useEffect:", error);
      setInitError(
        `Error initializing: ${error instanceof Error ? error.message : String(error)}`,
      );
    }

    console.log("========== App.tsx: useEffect completed ==========");
  }, []);

  console.log("[DEBUG-RENDER] App rendering with state:", { 
    isInitialized, 
    hasInitError: !!initError 
  });

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 text-gray-900">
      <QueryClientProvider client={queryClient}>
        <ErrorBoundary>
          <div className="container mx-auto px-4 py-8">
            {initError ? (
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <h2 className="text-lg font-semibold mb-2">
                  אירעה שגיאה באתחול
                </h2>
                <p>{initError}</p>
                <p className="mt-2 text-sm">
                  וודא שאתה משתמש ב-URL עם פרמטר instanceId, לדוגמה:
                  <br />
                  <code className="bg-gray-200 px-2 py-1 rounded">
                    https://wix-tool-hub-tonyboom3d.replit.app/?instanceId=b12bfa15-eed5-4bc1-a70e-ce6d3ab17f9c
                  </code>
                </p>
                <button 
                  onClick={() => {
                    console.log("[DEBUG-ACTION] Debug button clicked, logging window and environment data");
                    console.log("[DEBUG-ENV] Window location:", window.location);
                    console.log("[DEBUG-ENV] User Agent:", navigator.userAgent);
                    console.log("[DEBUG-ENV] Referrer:", document.referrer);
                    // Try to get directly via params as fallback
                    try {
                      const params = new URLSearchParams(window.location.search);
                      if (params.has("instanceId")) {
                        const instanceId = params.get("instanceId");
                        console.log("[DEBUG-ACTION] Found instanceId in params, trying to initialize:", instanceId);
                        if (instanceId) {
                          initWixApiClient(instanceId);
                          setIsInitialized(true);
                          setInitError(null);
                        }
                      }
                    } catch (e) {
                      console.error("[DEBUG-ACTION] Error in debug button action:", e);
                    }
                  }}
                  className="mt-4 px-4 py-2 bg-blue-500 text-white rounded"
                >
                  Debug Info
                </button>
              </div>
            ) : !isInitialized ? (
              <div className="text-center p-8">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto"></div>
                <p className="mt-4">טוען...</p>
                <p className="text-sm text-gray-500 mt-2">
                  {`Checking for instanceId...`}
                </p>
              </div>
            ) : (
              <>
                <div className="text-xs text-gray-400 mb-4">
                  Debug: WixApiClient initialized successfully
                </div>
                <SettingsManager />
              </>
            )}
          </div>
        </ErrorBoundary>
      </QueryClientProvider>
    </div>
  );
}

export default App;