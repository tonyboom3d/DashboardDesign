import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import ShippingBar from '@/components/ui/shipping-bar';
import { ShippingBarSettings, WixProduct, Cart, CartItem } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

const CartDemo = () => {
  const { toast } = useToast();
  const [cart, setCart] = useState<Cart>({
    items: [
      {
        productId: "product-1",
        title: "Premium Headphones",
        price: 39.99,
        quantity: 1,
        imageUrl: "https://images.unsplash.com/photo-1560343090-f0409e92791a?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80"
      },
      {
        productId: "product-2",
        title: "Running Shoes",
        price: 89.95,
        quantity: 1,
        imageUrl: "https://images.unsplash.com/photo-1491553895911-0055eca6402d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80"
      },
      {
        productId: "product-3",
        title: "Cotton T-Shirt",
        price: 10.05,
        quantity: 1,
        imageUrl: "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80"
      }
    ],
    total: 139.99
  });
  
  // Fetch settings
  const { data: settings, isLoading: isSettingsLoading } = useQuery<ShippingBarSettings>({
    queryKey: ['/api/settings'],
  });
  
  // Fetch available products for suggestions
  const { data: availableProducts, isLoading: isProductsLoading } = useQuery<WixProduct[]>({
    queryKey: ['/api/demo/products'],
  });
  
  // Update item quantity
  const updateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity < 1) return;
    
    const updatedItems = cart.items.map(item => {
      if (item.productId === productId) {
        return { ...item, quantity: newQuantity };
      }
      return item;
    });
    
    const newTotal = updatedItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    setCart({
      items: updatedItems,
      total: parseFloat(newTotal.toFixed(2))
    });
  };
  
  // Remove item from cart
  const removeItem = (productId: string) => {
    const updatedItems = cart.items.filter(item => item.productId !== productId);
    const newTotal = updatedItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    setCart({
      items: updatedItems,
      total: parseFloat(newTotal.toFixed(2))
    });
    
    toast({
      title: "Item removed",
      description: "The item has been removed from your cart."
    });
  };
  
  // Add product to cart
  const handleAddToCart = (productId: string) => {
    const product = availableProducts?.find(p => p.id === productId);
    
    if (product) {
      // Check if product already in cart
      const existingItem = cart.items.find(item => item.productId === productId);
      
      if (existingItem) {
        updateQuantity(productId, existingItem.quantity + 1);
      } else {
        const newItem: CartItem = {
          productId: product.id,
          title: product.title,
          price: product.price,
          quantity: 1,
          imageUrl: product.imageUrl
        };
        
        const newTotal = cart.total + product.price;
        
        setCart({
          items: [...cart.items, newItem],
          total: parseFloat(newTotal.toFixed(2))
        });
      }
      
      toast({
        title: "Product added to cart",
        description: `${product.title} has been added to your cart.`
      });
    }
  };
  
  if (isSettingsLoading || isProductsLoading || !settings) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <span className="text-primary font-medium text-lg">Free Shipping Bar</span>
              </div>
              <nav className="ml-8 flex space-x-8">
                <Link href="/">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Merchant Dashboard
                  </a>
                </Link>
                <Link href="/demo/product">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Product Page Demo
                  </a>
                </Link>
                <Link href="/demo/cart">
                  <a className="border-primary text-primary border-b-2 px-1 pt-1 text-sm font-medium">
                    Cart Page Demo
                  </a>
                </Link>
                <Link href="/demo/header">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Header Demo
                  </a>
                </Link>
                <Link href="/demo/mini-cart">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Mini Cart Demo
                  </a>
                </Link>
              </nav>
            </div>
          </div>
        </div>
      </header>

      <main className="py-8 px-4 sm:px-6 max-w-7xl mx-auto">
        <Card>
          <div className="p-4 border-b border-gray-200 bg-gray-100">
            <h2 className="text-xl font-medium text-gray-900">Cart Page Integration</h2>
            <p className="text-sm text-gray-600">The shipping bar is integrated into the cart page using Wix Slot.</p>
          </div>
          
          <CardContent className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <h3 className="text-lg font-medium text-gray-900">Your Cart ({cart.items.length} items)</h3>
                
                {/* ShippingBar Component */}
                {settings.enabled && settings.showOnCart && (
                  <div className="my-4">
                    <ShippingBar
                      settings={settings}
                      cartTotal={cart.total}
                      products={availableProducts || []}
                      onAddToCart={handleAddToCart}
                    />
                  </div>
                )}
                
                <div className="border-t border-b border-gray-200 divide-y divide-gray-200">
                  {cart.items.map((item) => (
                    <div key={item.productId} className="py-4 flex">
                      <div className="flex-shrink-0 w-24 h-24 bg-gray-200 rounded-md overflow-hidden">
                        {item.imageUrl && (
                          <img 
                            src={item.imageUrl} 
                            alt={item.title} 
                            className="w-full h-full object-center object-cover"
                          />
                        )}
                      </div>
                      <div className="ml-4 flex-1 flex flex-col">
                        <div>
                          <div className="flex justify-between text-base font-medium text-gray-900">
                            <h3>{item.title}</h3>
                            <p className="ml-4">${(item.price * item.quantity).toFixed(2)}</p>
                          </div>
                          <p className="mt-1 text-sm text-gray-500">
                            {item.productId === 'product-1' ? 'Black' : 
                             item.productId === 'product-2' ? 'Blue / Size 9' : 
                             'White / Medium'}
                          </p>
                        </div>
                        <div className="flex-1 flex items-end justify-between text-sm">
                          <div className="flex">
                            <button 
                              type="button" 
                              className="font-medium text-primary hover:text-primary-dark"
                              onClick={() => removeItem(item.productId)}
                            >
                              Remove
                            </button>
                          </div>
                          <div className="flex items-center border border-gray-300 rounded">
                            <button 
                              className="px-2 py-1 text-gray-500"
                              onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                            >
                              -
                            </button>
                            <span className="px-2 text-gray-700">{item.quantity}</span>
                            <button 
                              className="px-2 py-1 text-gray-500"
                              onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="lg:col-span-1">
                <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Order Summary</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <p className="text-gray-600">Subtotal</p>
                      <p className="font-medium text-gray-900">${cart.total.toFixed(2)}</p>
                    </div>
                    <div className="flex justify-between text-sm">
                      <p className="text-gray-600">Shipping</p>
                      <p className="font-medium text-gray-900">
                        {cart.total >= parseFloat(settings.threshold.toString()) ? 'Free' : '$10.00'}
                      </p>
                    </div>
                    <div className="flex justify-between text-sm">
                      <p className="text-gray-600">Tax</p>
                      <p className="font-medium text-gray-900">${(cart.total * 0.1).toFixed(2)}</p>
                    </div>
                    <div className="border-t border-gray-200 pt-2 flex justify-between">
                      <p className="text-base font-medium text-gray-900">Total</p>
                      <p className="text-base font-bold text-gray-900">
                        ${(
                          cart.total + 
                          (cart.total * 0.1) + 
                          (cart.total >= parseFloat(settings.threshold.toString()) ? 0 : 10)
                        ).toFixed(2)}
                      </p>
                    </div>
                  </div>
                  <div className="mt-6">
                    <Button className="w-full">
                      Checkout
                    </Button>
                  </div>
                  <div className="mt-6">
                    <div className="flex items-center">
                      <Input 
                        id="promo-code" 
                        name="promo-code" 
                        type="text" 
                        placeholder="Promo code" 
                        className="flex-1 rounded-r-none"
                      />
                      <Button className="rounded-l-none">
                        Apply
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default CartDemo;
