import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import ShippingBar from '@/components/ui/shipping-bar';
import ProductShippingBar from '@/components/ui/product-shipping-bar';
import { ShippingBarSettings, WixProduct, Cart } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

const ProductDemo = () => {
  const { toast } = useToast();
  const [cartTotal, setCartTotal] = useState(39.99);
  
  // Fetch settings
  const { data: settings, isLoading: isSettingsLoading } = useQuery<ShippingBarSettings>({
    queryKey: ['/api/settings'],
  });
  
  // Fetch available products for suggestions
  const { data: availableProducts, isLoading: isProductsLoading } = useQuery<WixProduct[]>({
    queryKey: ['/api/demo/products'],
  });
  
  // In real implementation, we would fetch cart data here
  // For now, simulate adding to cart
  const handleAddToCart = (productId: string) => {
    const product = availableProducts?.find(p => p.id === productId);
    
    if (product) {
      setCartTotal(prev => prev + product.price);
      
      toast({
        title: "Product added to cart",
        description: `${product.title} has been added to your cart.`
      });
    }
  };
  
  if (isSettingsLoading || isProductsLoading || !settings) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <span className="text-primary font-medium text-lg">Free Shipping Bar</span>
              </div>
              <nav className="ml-8 flex space-x-8">
                <Link href="/">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Merchant Dashboard
                  </a>
                </Link>
                <Link href="/demo/product">
                  <a className="border-primary text-primary border-b-2 px-1 pt-1 text-sm font-medium">
                    Product Page Demo
                  </a>
                </Link>
                <Link href="/demo/cart">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Cart Page Demo
                  </a>
                </Link>
                <Link href="/demo/header">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Header Demo
                  </a>
                </Link>
                <Link href="/demo/mini-cart">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Mini Cart Demo
                  </a>
                </Link>
              </nav>
            </div>
          </div>
        </div>
      </header>

      <main className="py-8 px-4 sm:px-6 max-w-7xl mx-auto">
        <Card>
          <div className="p-4 border-b border-gray-200 bg-gray-100">
            <h2 className="text-xl font-medium text-gray-900">Product Page Integration</h2>
            <p className="text-sm text-gray-600">The shipping bar is integrated into the product page using Wix Slot.</p>
          </div>
          
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="aspect-w-1 aspect-h-1 bg-gray-200 rounded-lg overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1560343090-f0409e92791a?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80" 
                  alt="Premium Headphones" 
                  className="w-full h-full object-center object-cover"
                />
              </div>
              <div className="flex flex-col">
                <h3 className="text-2xl font-medium text-gray-900 mb-2">Premium Headphones</h3>
                
                <div className="flex items-center mb-4">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <svg key={star} className="h-5 w-5 text-yellow-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                  <p className="ml-2 text-sm text-gray-500">42 reviews</p>
                </div>
                
                <p className="text-3xl font-bold text-gray-900 mb-4">$39.99</p>
                <p className="text-sm text-gray-600 mb-6">Experience premium sound quality with these comfortable, wireless headphones featuring noise cancellation technology and long battery life.</p>

                {/* ProductShippingBar Component */}
                {settings.enabled && settings.showOnProduct && (
                  <ProductShippingBar
                    settings={settings}
                    cartTotal={cartTotal}
                    suggestedProducts={availableProducts || []}
                    onAddToCart={handleAddToCart}
                    className="mb-6"
                  />
                )}
                
                <div className="flex space-x-3 mt-auto">
                  <select className="w-1/3 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                  </select>
                  <Button 
                    className="flex-1"
                    onClick={() => {
                      setCartTotal(prev => prev + 39.99);
                      toast({
                        title: "Product added to cart",
                        description: "Premium Headphones has been added to your cart."
                      });
                    }}
                  >
                    Add to Cart
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default ProductDemo;
