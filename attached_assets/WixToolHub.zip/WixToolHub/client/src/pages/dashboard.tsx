import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import ShippingBarDashboard from '@/components/shipping-bar-dashboard';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { ShippingBarSettings, WixProduct, SelectedProduct } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

const Dashboard = () => {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Fetch settings data
  const { data: settings, isLoading: isSettingsLoading } = useQuery<ShippingBarSettings>({
    queryKey: ['/api/settings'],
  });
  
  // Fetch selected products
  const { data: selectedProducts, isLoading: isProductsLoading } = useQuery<SelectedProduct[]>({
    queryKey: ['/api/products'],
  });
  
  // Fetch available products for selection
  const { data: availableProducts, isLoading: isAvailableProductsLoading } = useQuery<WixProduct[]>({
    queryKey: ['/api/demo/products'],
  });
  
  // Navigate to demo page
  const navigateToDemo = (demoType: string) => {
    setLocation(`/${demoType}-demo`);
  };
  
  // Check if we are in Wix dashboard
  const isWixDashboard = typeof window !== 'undefined' && 
                       window.parent && 
                       window.parent.location && 
                       window.parent.location.href.includes('wix.com');
  
  console.log("isWixDashboard:", isWixDashboard);
  console.log("Current settings:", settings);
  console.log("Loading state:", isSettingsLoading);
  
  // Loading state
  if (isSettingsLoading && !isWixDashboard) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="grid grid-cols-1 gap-4">
        <ShippingBarDashboard />
      </div>
    </div>
  );
};

export default Dashboard;