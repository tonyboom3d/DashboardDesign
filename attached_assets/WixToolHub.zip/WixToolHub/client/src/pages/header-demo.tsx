import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import ShippingBar from '@/components/ui/shipping-bar';
import { ShippingBarSettings, WixProduct } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

const HeaderDemo = () => {
  const { toast } = useToast();
  const [cartTotal, setCartTotal] = useState(139.99);
  const [showBar, setShowBar] = useState(true);
  
  // Fetch settings
  const { data: settings, isLoading: isSettingsLoading } = useQuery<ShippingBarSettings>({
    queryKey: ['/api/settings'],
  });
  
  // Fetch available products for suggestions
  const { data: availableProducts, isLoading: isProductsLoading } = useQuery<WixProduct[]>({
    queryKey: ['/api/demo/products'],
  });
  
  // Handle adding product to cart
  const handleAddToCart = (productId: string) => {
    const product = availableProducts?.find(p => p.id === productId);
    
    if (product) {
      setCartTotal(prev => prev + product.price);
      
      toast({
        title: "Product added to cart",
        description: `${product.title} has been added to your cart.`
      });
    }
  };
  
  if (isSettingsLoading || isProductsLoading || !settings) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <span className="text-primary font-medium text-lg">Free Shipping Bar</span>
              </div>
              <nav className="ml-8 flex space-x-8">
                <Link href="/">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Merchant Dashboard
                  </a>
                </Link>
                <Link href="/demo/product">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Product Page Demo
                  </a>
                </Link>
                <Link href="/demo/cart">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Cart Page Demo
                  </a>
                </Link>
                <Link href="/demo/header">
                  <a className="border-primary text-primary border-b-2 px-1 pt-1 text-sm font-medium">
                    Header Demo
                  </a>
                </Link>
                <Link href="/demo/mini-cart">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Mini Cart Demo
                  </a>
                </Link>
              </nav>
            </div>
          </div>
        </div>
      </header>

      <main className="py-8 px-4 sm:px-6 max-w-7xl mx-auto">
        <Card>
          <div className="p-4 border-b border-gray-200 bg-gray-100">
            <h2 className="text-xl font-medium text-gray-900">Header Integration</h2>
            <p className="text-sm text-gray-600">The shipping bar is injected at the top of the website using JavaScript.</p>
          </div>
          
          <CardContent className="p-6">
            <div className="mb-4">
              {/* ShippingBar Component */}
              {settings.enabled && settings.showOnHeader && showBar && (
                <ShippingBar
                  settings={settings}
                  cartTotal={cartTotal}
                  products={availableProducts || []}
                  onAddToCart={handleAddToCart}
                  variant="header"
                />
              )}
              
              <div className="flex justify-between items-center border-b border-gray-200 py-4">
                <div className="flex-shrink-0">
                  <span className="font-semibold text-xl">WIXSTORE</span>
                </div>
                <nav className="hidden md:flex space-x-8">
                  <a href="#" className="text-gray-600 hover:text-primary">Home</a>
                  <a href="#" className="text-gray-600 hover:text-primary">Shop</a>
                  <a href="#" className="text-gray-600 hover:text-primary">Collections</a>
                  <a href="#" className="text-gray-600 hover:text-primary">About</a>
                  <a href="#" className="text-gray-600 hover:text-primary">Contact</a>
                </nav>
                <div className="flex items-center">
                  <button className="p-2 text-gray-600 hover:text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                  </button>
                  <button className="p-2 text-gray-600 hover:text-primary relative">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                    </svg>
                    <span className="absolute top-0 right-0 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">3</span>
                  </button>
                  <button className="p-2 text-gray-600 hover:text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <div className="aspect-w-16 aspect-h-6 bg-gray-200 rounded-lg overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=400&q=80" 
                  alt="Hero Image" 
                  className="w-full h-full object-center object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex items-center">
                  <div className="px-8 py-4 text-white">
                    <h2 className="text-3xl font-bold mb-2">Summer Collection</h2>
                    <p className="text-xl mb-4">Get 20% off new arrivals</p>
                    <Button variant="secondary" className="bg-white text-gray-900 hover:bg-gray-100">
                      Shop Now
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gray-100 p-4 rounded-lg">
                  <div className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                    </svg>
                    <div className="ml-3">
                      <h3 className="font-medium text-gray-900">Free Shipping</h3>
                      <p className="text-sm text-gray-600">On orders over ${settings.threshold}</p>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-100 p-4 rounded-lg">
                  <div className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <div className="ml-3">
                      <h3 className="font-medium text-gray-900">24/7 Support</h3>
                      <p className="text-sm text-gray-600">Customer service</p>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-100 p-4 rounded-lg">
                  <div className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                    <div className="ml-3">
                      <h3 className="font-medium text-gray-900">Secure Payments</h3>
                      <p className="text-sm text-gray-600">100% secure checkout</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default HeaderDemo;
