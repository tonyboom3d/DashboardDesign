import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import ShippingBar from '@/components/ui/shipping-bar';
import { ShippingBarSettings, WixProduct, Cart } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

const MiniCartDemo = () => {
  const { toast } = useToast();
  const [isCartOpen, setIsCartOpen] = useState(true);
  const [cart, setCart] = useState<Cart>({
    items: [
      {
        productId: "product-1",
        title: "Premium Headphones",
        price: 39.99,
        quantity: 1,
        imageUrl: "https://images.unsplash.com/photo-1560343090-f0409e92791a?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80"
      },
      {
        productId: "product-2",
        title: "Running Shoes",
        price: 89.95,
        quantity: 1,
        imageUrl: "https://images.unsplash.com/photo-1491553895911-0055eca6402d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80"
      },
      {
        productId: "product-3",
        title: "Cotton T-Shirt",
        price: 10.05,
        quantity: 1,
        imageUrl: "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80"
      }
    ],
    total: 139.99
  });
  
  // Fetch settings
  const { data: settings, isLoading: isSettingsLoading } = useQuery<ShippingBarSettings>({
    queryKey: ['/api/settings'],
  });
  
  // Fetch available products for suggestions
  const { data: availableProducts, isLoading: isProductsLoading } = useQuery<WixProduct[]>({
    queryKey: ['/api/demo/products'],
  });
  
  // Handle adding product to cart
  const handleAddToCart = (productId: string) => {
    const product = availableProducts?.find(p => p.id === productId);
    
    if (product) {
      // Update cart total
      const newTotal = cart.total + product.price;
      
      // Add to cart items
      const newItem = {
        productId: product.id,
        title: product.title,
        price: product.price,
        quantity: 1,
        imageUrl: product.imageUrl
      };
      
      setCart({
        items: [...cart.items, newItem],
        total: parseFloat(newTotal.toFixed(2))
      });
      
      toast({
        title: "Product added to cart",
        description: `${product.title} has been added to your cart.`
      });
    }
  };
  
  // Remove item from cart
  const removeItem = (productId: string) => {
    const itemToRemove = cart.items.find(item => item.productId === productId);
    
    if (itemToRemove) {
      const newTotal = cart.total - (itemToRemove.price * itemToRemove.quantity);
      
      setCart({
        items: cart.items.filter(item => item.productId !== productId),
        total: parseFloat(newTotal.toFixed(2))
      });
      
      toast({
        title: "Item removed",
        description: "The item has been removed from your cart."
      });
    }
  };
  
  if (isSettingsLoading || isProductsLoading || !settings) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <span className="text-primary font-medium text-lg">Free Shipping Bar</span>
              </div>
              <nav className="ml-8 flex space-x-8">
                <Link href="/">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Merchant Dashboard
                  </a>
                </Link>
                <Link href="/demo/product">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Product Page Demo
                  </a>
                </Link>
                <Link href="/demo/cart">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Cart Page Demo
                  </a>
                </Link>
                <Link href="/demo/header">
                  <a className="border-transparent text-gray-500 hover:text-gray-700 px-1 pt-1 text-sm font-medium">
                    Header Demo
                  </a>
                </Link>
                <Link href="/demo/mini-cart">
                  <a className="border-primary text-primary border-b-2 px-1 pt-1 text-sm font-medium">
                    Mini Cart Demo
                  </a>
                </Link>
              </nav>
            </div>
          </div>
        </div>
      </header>

      <main className="py-8 px-4 sm:px-6 max-w-7xl mx-auto">
        <Card>
          <div className="p-4 border-b border-gray-200 bg-gray-100">
            <h2 className="text-xl font-medium text-gray-900">Mini Cart Integration</h2>
            <p className="text-sm text-gray-600">The shipping bar is injected into the mini cart using JavaScript.</p>
          </div>
          
          <CardContent className="p-6">
            <div className="flex justify-end">
              <div className="relative">
                <button 
                  className="p-2 border border-gray-300 rounded-md flex items-center text-gray-600 hover:text-primary"
                  onClick={() => setIsCartOpen(!isCartOpen)}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                  </svg>
                  <span className="ml-1 text-sm">Cart</span>
                  <span className="absolute -top-1 -right-1 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {cart.items.length}
                  </span>
                </button>
                
                {/* Mini Cart Dropdown */}
                {isCartOpen && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg z-10 border border-gray-200">
                    <div className="p-4 border-b border-gray-200">
                      <h3 className="text-lg font-medium text-gray-900">Your Cart ({cart.items.length})</h3>
                    </div>
                    
                    {/* ShippingBar Component */}
                    {settings.enabled && settings.showOnMiniCart && (
                      <ShippingBar
                        settings={settings}
                        cartTotal={cart.total}
                        products={availableProducts || []}
                        onAddToCart={handleAddToCart}
                        variant="mini"
                      />
                    )}
                    
                    <div className="max-h-60 overflow-y-auto">
                      {cart.items.map((item) => (
                        <div key={item.productId} className="p-4 flex border-b border-gray-200">
                          <div className="flex-shrink-0 w-16 h-16 bg-gray-200 rounded-md overflow-hidden">
                            {item.imageUrl && (
                              <img 
                                src={item.imageUrl} 
                                alt={item.title} 
                                className="w-full h-full object-center object-cover"
                              />
                            )}
                          </div>
                          <div className="ml-3 flex-1 flex flex-col">
                            <div>
                              <div className="flex justify-between text-sm font-medium text-gray-900">
                                <h3 className="truncate">{item.title}</h3>
                                <p className="ml-1">${item.price.toFixed(2)}</p>
                              </div>
                              <p className="mt-1 text-xs text-gray-500">
                                {item.productId === 'product-1' ? 'Black' : 
                                 item.productId === 'product-2' ? 'Blue / Size 9' : 
                                 'White / Medium'}
                              </p>
                            </div>
                            <div className="flex-1 flex items-end justify-between text-xs">
                              <p className="text-gray-500">Qty {item.quantity}</p>
                              <button 
                                type="button" 
                                className="font-medium text-primary hover:text-primary-dark"
                                onClick={() => removeItem(item.productId)}
                              >
                                Remove
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="p-4 border-t border-gray-200">
                      <div className="flex justify-between text-sm font-medium">
                        <p className="text-gray-600">Subtotal</p>
                        <p className="font-medium text-gray-900">${cart.total.toFixed(2)}</p>
                      </div>
                      <div className="mt-4">
                        <Button className="w-full">
                          Checkout
                        </Button>
                        <Button variant="outline" className="w-full mt-2">
                          View Cart
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default MiniCartDemo;
