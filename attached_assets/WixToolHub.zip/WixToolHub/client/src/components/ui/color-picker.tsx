import React, { useState, useEffect } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { Check } from 'lucide-react';

interface ColorPickerProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  className?: string;
}

// Preset colors
const presetColors = [
  "#000000", "#FFFFFF", "#F5F5F5", "#808080", 
  "#FF0000", "#FF4500", "#FF6347", "#FF7F50", 
  "#FFA500", "#FFD700", "#FFFF00", "#ADFF2F",
  "#00FF00", "#32CD32", "#008000", "#006400",
  "#00FFFF", "#00CED1", "#0000FF", "#0000CD",
  "#8A2BE2", "#9370DB", "#800080", "#4B0082",
  "#FF00FF", "#C71585", "#DB7093", "#FFC0CB"
];

// Store recently used colors in local storage
const getRecentColors = (): string[] => {
  try {
    const stored = localStorage.getItem('recentColors');
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    return [];
  }
};

const saveRecentColor = (color: string) => {
  try {
    let recentColors = getRecentColors();
    // Remove if exists
    recentColors = recentColors.filter(c => c !== color);
    // Add to front
    recentColors.unshift(color);
    // Limit to 8 colors
    recentColors = recentColors.slice(0, 8);
    localStorage.setItem('recentColors', JSON.stringify(recentColors));
  } catch (e) {
    // Ignore errors
  }
};

const ColorPicker: React.FC<ColorPickerProps> = ({
  id,
  label,
  value,
  onChange,
  className = ''
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [currentColor, setCurrentColor] = useState(value || '#000000');
  const [recentColors, setRecentColors] = useState<string[]>([]);
  
  // Load recent colors on mount
  useEffect(() => {
    setRecentColors(getRecentColors());
  }, []);
  
  // Update when value changes externally
  useEffect(() => {
    setCurrentColor(value || '#000000');
  }, [value]);
  
  const handleColorChange = (color: string) => {
    setCurrentColor(color);
  };
  
  const handleColorSelect = (color: string) => {
    onChange(color);
    saveRecentColor(color);
    setRecentColors(getRecentColors());
    setIsOpen(false);
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newColor = e.target.value;
    setCurrentColor(newColor);
  };
  
  const handleInputBlur = () => {
    // Validate color on blur
    if (/^#[0-9A-F]{6}$/i.test(currentColor)) {
      onChange(currentColor);
      saveRecentColor(currentColor);
      setRecentColors(getRecentColors());
    } else {
      setCurrentColor(value || '#000000');
    }
  };

  // Check if a color is light (to determine text color)
  const isLightColor = (hex: string) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return (r * 0.299 + g * 0.587 + b * 0.114) > 150;
  };

  return (
    <div className={className}>
      <Label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </Label>
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            id={id}
            variant="outline"
            className="w-full justify-between border border-gray-300 bg-transparent hover:bg-gray-100"
            style={{ 
              backgroundColor: value,
              color: isLightColor(value) ? '#000000' : '#FFFFFF',
              textShadow: isLightColor(value) ? 'none' : '0 0 2px rgba(0,0,0,0.5)'
            }}
          >
            <div className="flex gap-2 items-center">
              <div 
                className="w-4 h-4 border border-gray-300 shadow-sm" 
                style={{ backgroundColor: value }}
              />
              <span>{value}</span>
            </div>
            <span className="text-xs opacity-50">↓</span>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-64 p-3" align="start">
          <div className="space-y-3">
            <div className="flex flex-col">
              <Label className="text-xs mb-1">צבע נוכחי</Label>
              <div 
                className="w-full h-10 rounded border shadow-sm flex justify-center items-center"
                style={{ 
                  backgroundColor: currentColor,
                  color: isLightColor(currentColor) ? '#000000' : '#FFFFFF',
                  textShadow: isLightColor(currentColor) ? 'none' : '0 0 2px rgba(0,0,0,0.5)'
                }}
              >
                {currentColor}
              </div>
            </div>
            
            <div className="flex flex-col">
              <Label htmlFor={`${id}-input`} className="text-xs mb-1">
                בחר צבע
              </Label>
              <div className="flex gap-2">
                <div className="relative w-10 h-10">
                  <Input
                    type="color"
                    value={currentColor}
                    onChange={(e) => handleColorChange(e.target.value)}
                    className="absolute inset-0 w-full h-full p-0 border rounded opacity-0 cursor-pointer"
                  />
                  <div 
                    className="absolute inset-0 w-full h-full border rounded"
                    style={{ backgroundColor: currentColor }}
                  ></div>
                </div>
                <Input
                  id={`${id}-input`}
                  type="text"
                  value={currentColor}
                  onChange={handleInputChange}
                  onBlur={handleInputBlur}
                  maxLength={7}
                  className="flex-1"
                />
                <Button 
                  size="sm"
                  onClick={() => handleColorSelect(currentColor)}
                >
                  <Check className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            {recentColors.length > 0 && (
              <div className="space-y-1">
                <Label className="text-xs">צבעים אחרונים</Label>
                <div className="grid grid-cols-8 gap-1">
                  {recentColors.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => handleColorSelect(color)}
                      className="w-6 h-6 rounded-sm border border-gray-300 shadow-sm transition hover:scale-110"
                      style={{ backgroundColor: color }}
                      title={color}
                    ></button>
                  ))}
                </div>
              </div>
            )}
            
            <div className="space-y-1">
              <Label className="text-xs">צבעים מוגדרים מראש</Label>
              <div className="grid grid-cols-8 gap-1">
                {presetColors.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => handleColorSelect(color)}
                    className="w-6 h-6 rounded-sm border border-gray-300 shadow-sm transition hover:scale-110"
                    style={{ backgroundColor: color }}
                    title={color}
                  ></button>
                ))}
              </div>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default ColorPicker;