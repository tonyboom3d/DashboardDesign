import React from 'react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';

interface CurrencyPickerProps {
  id: string;
  label: string;
  currencyCode: string;
  currencySymbol: string;
  onCurrencyChange: (code: string, symbol: string) => void;
  className?: string;
}

// Common currencies
export const currencies = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "ILS", symbol: "₪", name: "Israeli Shekel" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
  { code: "RUB", symbol: "₽", name: "Russian Ruble" },
  { code: "CNY", symbol: "¥", name: "Chinese Yuan" },
  { code: "BRL", symbol: "R$", name: "Brazilian Real" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "AED", symbol: "د.إ", name: "UAE Dirham" },
];

const CurrencyPicker: React.FC<CurrencyPickerProps> = ({
  id,
  label,
  currencyCode,
  currencySymbol,
  onCurrencyChange,
  className = ''
}) => {
  const handleCurrencyChange = (code: string) => {
    const currency = currencies.find(c => c.code === code);
    if (currency) {
      onCurrencyChange(currency.code, currency.symbol);
    }
  };

  return (
    <div className={className}>
      <Label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </Label>
      <Select 
        value={currencyCode} 
        onValueChange={handleCurrencyChange}
      >
        <SelectTrigger 
          id={id}
          className={cn("w-full border border-gray-300")}
        >
          <SelectValue placeholder="Select Currency" />
        </SelectTrigger>
        <SelectContent>
          {currencies.map((currency) => (
            <SelectItem key={currency.code} value={currency.code}>
              <div className="flex items-center">
                <span className="mr-2">{currency.symbol}</span>
                <span>{currency.name}</span>
                <span className="ml-2 text-gray-500">({currency.code})</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <div className="mt-2 flex items-center">
        <div className="text-sm text-gray-500">Currency Symbol:</div>
        <div className="ml-2 font-medium text-lg">{currencySymbol}</div>
      </div>
    </div>
  );
};

export default CurrencyPicker;