import React from 'react';
import { Progress } from '@/components/ui/progress';
import { ShippingBarSettings, WixProduct } from '@shared/schema';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import ProductSuggestion from './product-suggestion';
import { Package, ShoppingBag } from 'lucide-react';

// Helper function to adjust color brightness/darkness for gradient effect
const adjustColor = (hexColor: string, factor: number): string => {
  // Parse the hex color to RGB
  const r = parseInt(hexColor.slice(1, 3), 16);
  const g = parseInt(hexColor.slice(3, 5), 16);
  const b = parseInt(hexColor.slice(5, 7), 16);
  
  // Adjust brightness or darkness
  const adjustedR = Math.round(r * factor);
  const adjustedG = Math.round(g * factor);
  const adjustedB = Math.round(b * factor);
  
  // Ensure values are in valid range (0-255)
  const clampedR = Math.min(255, Math.max(0, adjustedR));
  const clampedG = Math.min(255, Math.max(0, adjustedG));
  const clampedB = Math.min(255, Math.max(0, adjustedB));
  
  // Convert back to hex
  return `#${clampedR.toString(16).padStart(2, '0')}${clampedG.toString(16).padStart(2, '0')}${clampedB.toString(16).padStart(2, '0')}`;
};

interface ProductShippingBarProps {
  settings: ShippingBarSettings;
  cartTotal: number;
  suggestedProducts?: WixProduct[];
  onAddToCart?: (productId: string) => void;
  className?: string;
}

const ProductShippingBar = ({
  settings,
  cartTotal,
  suggestedProducts = [],
  onAddToCart,
  className
}: ProductShippingBarProps) => {
  // Calculate shipping threshold metrics
  const threshold = parseFloat(settings.threshold.toString());
  const remaining = Math.max(threshold - cartTotal, 0);
  const progress = Math.min((cartTotal / threshold) * 100, 100);
  const isQualified = cartTotal >= threshold;
  
  // Format remaining amount
  const formattedRemaining = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: settings.currencyCode || 'USD',
    currencyDisplay: 'symbol'
  }).format(remaining);
  
  // Format cart total amount
  const formattedCartTotal = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: settings.currencyCode || 'USD',
    currencyDisplay: 'symbol'
  }).format(cartTotal);
  
  // Format threshold amount
  const formattedThreshold = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: settings.currencyCode || 'USD',
    currencyDisplay: 'symbol'
  }).format(threshold);

  // Get progress bar styles based on settings
  const getProgressBarStyles = () => {
    let indicatorStyle = {};
    
    if (settings.barStyle === 'gradient') {
      indicatorStyle = { 
        background: `linear-gradient(to right, ${settings.barColor || '#4f46e5'}, ${adjustColor(settings.barColor || '#4f46e5', 0.7)})` 
      };
    } else if (settings.barStyle === 'animated') {
      indicatorStyle = {
        backgroundImage: `linear-gradient(45deg, ${settings.barColor || '#4f46e5'} 25%, transparent 25%, transparent 50%, ${settings.barColor || '#4f46e5'} 50%, ${settings.barColor || '#4f46e5'} 75%, transparent 75%, transparent)`,
        backgroundSize: '1rem 1rem',
        animation: 'progress-bar-stripes 1s linear infinite'
      };
    }
    
    return {
      indicatorColor: settings.barColor || '#4f46e5',
      indicatorStyle,
      backgroundColor: settings.progressBgColor || '#E0E0E0'
    };
  };
  
  // Get display message based on cart state
  const getMessage = () => {
    if (isQualified) {
      return (
        <span className="flex items-center gap-2">
          {settings.iconEmoji ? settings.iconEmoji : '🎉'} 
          {settings.successText || "Congratulations! You qualify for FREE SHIPPING!"}
        </span>
      );
    } else if (cartTotal === 0) {
      return (
        <span className="flex items-center gap-2">
          <Package size={16} /> 
          {`Free Shipping for orders from ${formattedThreshold}`}
        </span>
      );
    } else {
      let message = settings.barText || "${remaining} away from FREE SHIPPING!";
      message = message.replace('${remaining}', formattedRemaining);
      
      return (
        <span className="flex items-center gap-2">
          {settings.iconEmoji ? (
            <span>{settings.iconEmoji}</span>
          ) : (
            <ShoppingBag size={16} />
          )}
          {message}
        </span>
      );
    }
  };
  
  // Apply RTL/LTR text direction
  const textDir = settings.textDirection || 'ltr';
  
  // Get background styles based on settings
  const getBackgroundStyle = () => {
    const borderStyle = settings.borderThickness > 0 
      ? `${settings.borderThickness}px solid ${settings.borderColor || '#E0E0E0'}` 
      : '1px solid #E0E0E020';
      
    if (settings.bgBarStyle === 'gradient') {
      // Create a gradient with transparency
      const bgColor = settings.backgroundColor || '#F5F5F5';
      const getRgba = (hex: string, alpha = 1) => {
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
      };
      
      return {
        background: `linear-gradient(to right, ${bgColor}, ${getRgba(bgColor, 0.6)})`,
        border: borderStyle
      };
    } else {
      // Simple style
      return { 
        backgroundColor: settings.backgroundColor || '#F5F5F5',
        border: borderStyle
      };
    }
  };
  
  // Simplified suggested products section
  const renderSuggestedProducts = () => {
    if (!suggestedProducts || suggestedProducts.length === 0 || isQualified) {
      return null;
    }
    
    // Limit to max suggestions from settings
    const maxToShow = Math.min(
      settings.maxSuggestions || 3, 
      suggestedProducts.length
    );
    
    const displayProducts = suggestedProducts.slice(0, maxToShow);
    
    return (
      <div className="mt-4">
        <h4 className="text-sm font-medium mb-2 text-gray-700">
          Add to qualify for free shipping:
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
          {displayProducts.map(product => (
            <ProductSuggestion
              key={product.id}
              product={product}
              variant="default"
              onAddToCart={onAddToCart}
              accentColor={settings.accentColor}
              buttonText={settings.buttonText || "Add"}
              showAddButton={true}
            />
          ))}
        </div>
      </div>
    );
  };
  
  // Get progress bar styles
  const progressBarStyles = getProgressBarStyles();
  const backgroundStyle = getBackgroundStyle();
  
  return (
    <motion.div 
      className={cn(
        "rounded-lg p-4 shadow-sm", 
        className
      )}
      style={backgroundStyle}
      dir={textDir}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-3 gap-2">
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-1">
            Free Shipping Progress
          </h3>
          <p className="text-sm text-gray-500">
            {getMessage()}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-end">
            <span className="text-xs text-gray-500">Current Total:</span>
            <span className="font-semibold text-gray-900">{formattedCartTotal}</span>
          </div>
          <div className="w-px h-8 bg-gray-200" />
          <div className="flex flex-col items-end">
            <span className="text-xs text-gray-500">Free Shipping At:</span>
            <span className="font-semibold text-gray-900">{formattedThreshold}</span>
          </div>
        </div>
      </div>
      
      {/* Progress bar section */}
      <div className="relative mb-2">
        {settings.barStyle !== 'none' && (
          <div className="w-full rounded-full">
            <Progress 
              value={progress} 
              className="h-4 w-full"
              backgroundColor={progressBarStyles.backgroundColor}
              indicatorColor={progressBarStyles.indicatorColor}
              indicatorStyle={progressBarStyles.indicatorStyle}
            />
          </div>
        )}
        
        {!isQualified && (
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>{formattedCartTotal}</span>
            <span>{formattedThreshold}</span>
          </div>
        )}
        
        {isQualified && (
          <div className="text-center text-xs text-green-600 font-medium mt-1">
            Free shipping unlocked!
          </div>
        )}
      </div>
      
      {/* Suggested products section */}
      <AnimatePresence>
        {!isQualified && suggestedProducts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            {renderSuggestedProducts()}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default ProductShippingBar;