import React, { useState } from 'react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

interface EmojiPickerProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  className?: string;
}

const commonEmojis = [
  "🎁", "🎉", "🚚", "📦", "🛍️", "💰", "💸", "💲", "💯", 
  "⭐", "🔥", "✨", "🌟", "💫", "🎊", "🏷️", "🛒", "📢",
  "🚀", "👑", "💎", "🤑", "👍", "🍀", "🎯", "📣", "🗯️"
];

export default function EmojiPicker({ id, label, value, onChange, className }: EmojiPickerProps) {
  const [search, setSearch] = useState('');
  
  const filteredEmojis = search
    ? commonEmojis.filter(emoji => emoji.includes(search))
    : commonEmojis;

  return (
    <div className={className}>
      <Label htmlFor={id} className="text-sm font-medium text-gray-700">
        {label}
      </Label>
      <div className="mt-2 flex items-center gap-2">
        <Input
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="🎁"
          className="w-20"
        />
        
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="h-10">
              Select Emoji
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-64 p-3">
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Select an emoji</h4>
              <Input
                placeholder="Search..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="mb-2"
              />
              <div className="grid grid-cols-6 gap-2">
                {filteredEmojis.map((emoji) => (
                  <Button
                    key={emoji}
                    variant="ghost"
                    onClick={() => {
                      onChange(emoji);
                      setSearch('');
                    }}
                    className="h-8 w-8 p-0 text-lg hover:bg-slate-100"
                  >
                    {emoji}
                  </Button>
                ))}
              </div>
            </div>
          </PopoverContent>
        </Popover>
      </div>
    </div>
  );
}