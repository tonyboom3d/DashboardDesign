import React, { useEffect, useState } from 'react';
import { Progress } from '@/components/ui/progress';
import { Card } from '@/components/ui/card';
import ProductSuggestion from './product-suggestion';
import { ShippingBarSettings, WixProduct } from '@shared/schema';
import { cn } from '@/lib/utils';
import { AnimatePresence, motion } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';

// Helper function to adjust color brightness/darkness for gradient effect
const adjustColor = (hexColor: string, factor: number): string => {
  // Parse the hex color to RGB
  const r = parseInt(hexColor.slice(1, 3), 16);
  const g = parseInt(hexColor.slice(3, 5), 16);
  const b = parseInt(hexColor.slice(5, 7), 16);
  
  // Adjust brightness or darkness
  const adjustedR = Math.round(r * factor);
  const adjustedG = Math.round(g * factor);
  const adjustedB = Math.round(b * factor);
  
  // Ensure values are in valid range (0-255)
  const clampedR = Math.min(255, Math.max(0, adjustedR));
  const clampedG = Math.min(255, Math.max(0, adjustedG));
  const clampedB = Math.min(255, Math.max(0, adjustedB));
  
  // Convert back to hex
  return `#${clampedR.toString(16).padStart(2, '0')}${clampedG.toString(16).padStart(2, '0')}${clampedB.toString(16).padStart(2, '0')}`;
};

interface ShippingBarProps {
  settings: ShippingBarSettings;
  cartTotal: number;
  products?: WixProduct[];
  onAddToCart?: (productId: string) => void;
  variant?: 'default' | 'header' | 'mini';
}

const ShippingBar: React.FC<ShippingBarProps> = ({
  settings,
  cartTotal,
  products = [],
  onAddToCart,
  variant = 'default'
}) => {
  const threshold = parseFloat(settings.threshold.toString());
  const remaining = Math.max(threshold - cartTotal, 0);
  const progress = Math.min((cartTotal / threshold) * 100, 100);
  const isQualified = cartTotal >= threshold;
  const [currentProductIndex, setCurrentProductIndex] = useState(0);
  const [addedProducts, setAddedProducts] = useState<Set<string>>(new Set());
  
  // Track view count
  useEffect(() => {
    // In a real app, we would increment the view count on the server
    console.log('Shipping bar viewed');
  }, []);
  
  // Reset product index when cart total changes
  useEffect(() => {
    setCurrentProductIndex(0);
  }, [cartTotal]);
  
  // Filter product suggestions based on settings and hide added products
  const filteredProducts = products
    .filter(product => 
      // No longer filtering by price - show all products regardless of price
      !addedProducts.has(product.id) &&
      !product.hidden &&
      !product.outOfStock
    );
  
  // Handle product navigation
  const showNextProduct = () => {
    if (currentProductIndex < filteredProducts.length - 1) {
      setCurrentProductIndex(prev => prev + 1);
    } else {
      setCurrentProductIndex(0); // Loop back to the beginning
    }
  };
  
  const showPrevProduct = () => {
    if (currentProductIndex > 0) {
      setCurrentProductIndex(prev => prev - 1);
    } else {
      setCurrentProductIndex(filteredProducts.length - 1); // Loop to the end
    }
  };
  
  // Handle add to cart with tracking which products were added
  const handleAddToCart = (productId: string) => {
    if (onAddToCart) {
      setAddedProducts(prev => new Set(prev).add(productId));
      onAddToCart(productId);
    }
  };
  
  // Apply styles based on settings
  const getProgressBarStyle = () => {
    // This now only affects the root container style
    // The indicator styles are passed directly to the Progress component
    if (settings.barStyle === 'simple') {
      return {};
    } else if (settings.barStyle === 'gradient') {
      return {};
    } else if (settings.barStyle === 'animated') {
      return {};
    } else if (settings.barStyle === 'none') {
      return { display: 'none' };
    }
    return {};
  };
  
  // Apply styles for background bar
  const getBackgroundBarStyle = () => {
    const borderStyle = settings.borderThickness > 0 
      ? `${settings.borderThickness}px solid ${settings.borderColor || '#E0E0E0'}` 
      : 'none';
      
    if (settings.bgBarStyle === 'gradient') {
      // Create a properly formatted gradient with transparency
      const bgColor = settings.backgroundColor || '#F5F5F5';
      // Convert hex to rgba for proper transparency in the gradient
      const getRgba = (hex: string, alpha = 1) => {
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
      };
      
      return {
        background: `linear-gradient(to right, ${bgColor}, ${getRgba(bgColor, 0.6)})`,
        border: borderStyle
      };
    } else {
      // Simple style
      return { 
        backgroundColor: settings.backgroundColor || '#F5F5F5',
        border: borderStyle
      };
    }
  };
  
  const getContainerStyle = () => {
    const position = settings.position || 'top';
    
    if (variant === 'header') {
      let className = `py-2 px-3 relative ${position === 'top' ? 'top-0' : 'bottom-0'}`;
      return {
        className,
        style: { 
          background: settings.barColor,
          color: settings.textColor,
        }
      };
    } else if (variant === 'mini') {
      let className = `p-2 border-b ${position === 'top' ? 'top-0' : 'bottom-0'}`;
      return {
        className,
        style: { 
          background: settings.backgroundColor,
          border: `1px solid ${settings.accentColor}20`,
        }
      };
    }
    
    let className = `p-3 rounded-lg transition-all duration-300 ${position === 'top' ? 'top-0' : 'bottom-0'}`;
    return {
      className,
      style: { 
        background: settings.backgroundColor,
        border: `1px solid ${settings.accentColor}20`,
      }
    };
  };
  
  const getProgressHeight = () => {
    switch (variant) {
      case 'header': return 'h-2';
      case 'mini': return 'h-2';
      default: return 'h-4';
    }
  };
  
  const containerStyle = getContainerStyle();
  const progressStyle = getProgressBarStyle();
  const progressHeight = getProgressHeight();
  
  // Format remaining amount
  const formattedRemaining = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: settings.currencyCode || 'USD',
    currencyDisplay: 'symbol'
  }).format(remaining);
  
  // Static text when cart is empty or very low
  const getStaticText = () => {
    return `Free Shipping for orders from ${settings.currencySymbol}${threshold}`;
  };
  
  // Get display text with icon
  const getDisplayText = () => {
    let text;
    
    if (isQualified) {
      text = settings.successText;
    } else if (cartTotal === 0) {
      text = getStaticText();
    } else {
      text = settings.barText.replace('${remaining}', formattedRemaining);
    }
    
    if (settings.iconPosition === 'none' || !settings.iconEmoji) {
      return text;
    }
    
    if (settings.iconPosition === 'before') {
      return <>{settings.iconEmoji} {text}</>;
    } else {
      return <>{text} {settings.iconEmoji}</>;
    }
  };
  
  // Get text alignment class based on settings
  const getTextAlignClass = () => {
    if (settings.textAlign === 'center') {
      return 'text-center';
    } else if (settings.textAlign === 'right') {
      return 'text-right';
    } else if (settings.textAlign === 'left') {
      return 'text-left';
    }
    return ''; // Default
  };
  
  // Get message for product suggestions
  const suggestionsMessage = "Add to qualify:";
  
  // Apply RTL/LTR text direction
  const textDir = settings.textDirection || 'ltr';
  
  return (
    <motion.div 
      className={containerStyle.className} 
      style={containerStyle.style}
      dir={textDir}
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      transition={{ duration: 0.3 }}
    >
      {/* Conditionally render text above bar if position is top */}
      {settings.position === 'top' && (
        <motion.p 
          className={cn(
            "font-medium mb-2",
            variant === 'header' ? 'text-sm' : 'text-sm',
            getTextAlignClass()
          )}
          style={{ 
            color: settings.textColor || (variant === 'header' ? '#FFFFFF' : '#374151')
          }}
          key={isQualified ? 'qualified-top' : 'not-qualified-top'}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          {getDisplayText()}
        </motion.p>
      )}
      
      {/* Progress Bar */}
      {settings.barStyle !== 'none' && (
        <div className="w-full rounded-full mb-2" style={getBackgroundBarStyle()}>
          <Progress 
            value={Math.min(progress, 100)} 
            className={`${progressHeight} w-full`}
            style={progressStyle}
            backgroundColor={settings.progressBgColor || '#E0E0E0'}
            indicatorColor={settings.barColor || '#4f46e5'}
            indicatorStyle={settings.barStyle === 'gradient' ? 
              { background: `linear-gradient(to right, ${settings.barColor || '#4f46e5'}, ${adjustColor(settings.barColor || '#4f46e5', 0.7)})` } : 
              (settings.barStyle === 'animated' ? 
                {
                  backgroundImage: `linear-gradient(45deg, ${settings.barColor || '#4f46e5'} 25%, transparent 25%, transparent 50%, ${settings.barColor || '#4f46e5'} 50%, ${settings.barColor || '#4f46e5'} 75%, transparent 75%, transparent)`,
                  backgroundSize: '1rem 1rem',
                  animation: 'progress-bar-stripes 1s linear infinite'
                } : 
                {}
              )
            }
          />
        </div>
      )}
      
      {/* Conditionally render text below bar if position is bottom */}
      {settings.position !== 'top' && (
        <motion.p 
          className={cn(
            "font-medium mb-2",
            variant === 'header' ? 'text-sm' : 'text-sm',
            getTextAlignClass()
          )}
          style={{ 
            color: settings.textColor || (variant === 'header' ? '#FFFFFF' : '#374151')
          }}
          key={isQualified ? 'qualified-bottom' : 'not-qualified-bottom'}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          {getDisplayText()}
        </motion.p>
      )}
      
      {/* Product Suggestions */}
      <AnimatePresence>
        {!isQualified && filteredProducts.length > 0 && (
          <motion.div 
            className="mt-2"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <p 
              className={cn(
                "font-medium mb-2",
                variant === 'header' ? 'text-xs text-white/90' : 'text-xs text-gray-700',
                getTextAlignClass()
              )}
            >
              {suggestionsMessage}
            </p>
            
            {/* Product Navigation */}
            <div className="flex items-center w-full max-w-full">
              {filteredProducts.length > 1 && (
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="p-1 rounded-full text-gray-500 hover:text-gray-700 hover:bg-gray-100 flex-shrink-0"
                  onClick={showPrevProduct}
                  aria-label="Previous product"
                >
                  {textDir === 'rtl' ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
                </motion.button>
              )}
              
              <div className="flex-1 px-1 w-full overflow-hidden">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={filteredProducts[currentProductIndex]?.id || 'empty'}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="w-full"
                  >
                    {filteredProducts[currentProductIndex] && (
                      <ProductSuggestion
                        product={filteredProducts[currentProductIndex]}
                        variant={variant}
                        onAddToCart={handleAddToCart}
                        accentColor={settings.accentColor}
                        buttonText={settings.buttonText || "Add"}
                        originalPrice={filteredProducts[currentProductIndex].originalPrice}
                        showAddButton={settings.plan === "premium"}
                        maxTitleLength={variant === 'mini' ? 16 : 22}
                      />
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>
              
              {filteredProducts.length > 1 && (
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="p-1 rounded-full text-gray-500 hover:text-gray-700 hover:bg-gray-100 flex-shrink-0"
                  onClick={showNextProduct}
                  aria-label="Next product"
                >
                  {textDir === 'rtl' ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
                </motion.button>
              )}
            </div>
            
            {/* Pagination Dots */}
            {filteredProducts.length > 1 && (
              <div className="flex justify-center space-x-1 mt-2">
                {filteredProducts.map((_, idx) => (
                  <button
                    key={idx}
                    className={`w-1.5 h-1.5 rounded-full ${idx === currentProductIndex ? 'bg-gray-600' : 'bg-gray-300'}`}
                    onClick={() => setCurrentProductIndex(idx)}
                  />
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Close Button for Header Variant */}
      {variant === 'header' && (
        <button 
          className="absolute text-white/80 hover:text-white" 
          style={{ [textDir === 'rtl' ? 'left' : 'right']: '0.5rem', top: '0.5rem' }}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        </button>
      )}
    </motion.div>
  );
};

export default ShippingBar;
