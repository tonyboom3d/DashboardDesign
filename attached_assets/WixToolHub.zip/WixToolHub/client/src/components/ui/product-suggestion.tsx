import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { WixProduct } from '@shared/schema';
import { motion } from 'framer-motion';

interface ProductSuggestionProps {
  product: WixProduct;
  onAddToCart?: (productId: string) => void;
  variant?: 'default' | 'header' | 'mini';
  accentColor: string;
  buttonText?: string;
  isHidden?: boolean;
  originalPrice?: number;
  showAddButton?: boolean;
  maxTitleLength?: number;
}

const ProductSuggestion: React.FC<ProductSuggestionProps> = ({
  product,
  onAddToCart,
  variant = 'default',
  accentColor,
  buttonText = "Add",
  isHidden = false,
  originalPrice,
  showAddButton = true,
  maxTitleLength = 20
}) => {
  // Skip hidden products or products without inventory
  if (isHidden || product.outOfStock) {
    return null;
  }

  const handleAddToCart = () => {
    if (onAddToCart) {
      onAddToCart(product.id);
    }
  };

  // Truncate title if it's too long
  const truncateTitle = (title: string, maxLength: number) => {
    if (title.length <= maxLength) return title;
    return `${title.substring(0, maxLength)}...`;
  };

  const truncatedTitle = truncateTitle(product.title, maxTitleLength);

  const variantStyles = {
    default: 'p-3',
    header: 'p-2 pb-3',
    mini: 'p-2 pb-3'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.3 }}
      whileHover={{ scale: 1.02 }}
      className="w-full"
    >
      <Card className={`overflow-hidden ${variantStyles[variant]} border-gray-200 shadow-sm w-full`}>
        <div className="flex flex-col w-full">
          <div className="flex items-center gap-2 w-full">
            {product.imageUrl && (
              <div className="relative h-14 w-14 flex-shrink-0 bg-gray-100 rounded overflow-hidden">
                <img
                  src={product.imageUrl}
                  alt={truncatedTitle}
                  className="h-full w-full object-cover"
                />
              </div>
            )}
            
            <div className="flex-1 min-w-0 overflow-hidden">
              <h4 className="text-xs font-medium text-gray-900 truncate mb-1" title={product.title}>
                {truncatedTitle}
              </h4>
              
              <div className="flex items-baseline">
                <div className="text-sm font-semibold">
                  ${product.price.toFixed(2)}
                </div>
                
                {originalPrice && originalPrice > product.price && (
                  <div className="text-xs text-gray-500 line-through ml-2">
                    ${originalPrice.toFixed(2)}
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {showAddButton && (
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="mt-1.5"
            >
              <Button
                size="sm"
                className="h-7 text-xs font-medium text-white shadow-sm px-2 w-full"
                style={{ backgroundColor: accentColor }}
                onClick={handleAddToCart}
              >
                {buttonText}
              </Button>
            </motion.div>
          )}
        </div>
      </Card>
    </motion.div>
  );
};

export default ProductSuggestion;