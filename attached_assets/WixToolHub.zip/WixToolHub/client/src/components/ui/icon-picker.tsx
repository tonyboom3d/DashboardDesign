import React, { useState } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { cn } from '@/lib/utils';

interface IconPickerProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  className?: string;
}

// Common emojis
const emojis = [
  '🎁', '🚚', '🛒', '💰', '💎', '🔥', '⚡', '✨', '🌟', 
  '💯', '🎉', '🎊', '📦', '📱', '👕', '👟', '💄', '🧴', 
  '🛍️', '🏷️', '🎯', '⭐', '💝', '🎯', '🎀', '🎈', '🎵', 
  '💼', '🕑', '📢', '📣'
];

const IconPicker: React.FC<IconPickerProps> = ({
  id,
  label,
  value,
  onChange,
  className = ''
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  
  const handleEmojiSelect = (emoji: string) => {
    onChange(emoji);
  };

  return (
    <div className={className}>
      <Label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </Label>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            id={id}
            variant="outline"
            className={cn(
              "w-full justify-between border border-gray-300 bg-transparent hover:bg-gray-100",
              !value && "text-muted-foreground"
            )}
          >
            {value ? (
              <span className="text-2xl">{value}</span>
            ) : (
              <span>בחר אייקון</span>
            )}
            <span className="text-xs opacity-50">↓</span>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-64 p-3" align="start">
          <div className="space-y-2">
            <p className="text-sm text-gray-500">
              אייקון נבחר: <span className="text-2xl">{value}</span>
            </p>
            <Input
              type="text"
              placeholder="חיפוש..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="text-sm"
            />
            <div className="grid grid-cols-6 gap-2 mt-2 h-40 overflow-y-auto">
              {emojis.map((emoji) => (
                <Button
                  key={emoji}
                  type="button"
                  variant="ghost"
                  className={cn("h-9 w-9 p-0", emoji === value && "bg-primary/20")}
                  onClick={() => handleEmojiSelect(emoji)}
                >
                  <span className="text-lg">{emoji}</span>
                </Button>
              ))}
            </div>
            <div className="mt-3 pt-3 border-t">
              <div className="flex items-center space-x-2">
                <Input
                  type="text"
                  value={value}
                  onChange={(e) => onChange(e.target.value)}
                  className="text-lg text-center"
                  maxLength={2}
                />
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => onChange('')}
                  className="text-xs"
                >
                  נקה
                </Button>
              </div>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default IconPicker;