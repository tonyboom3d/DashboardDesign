
import React from 'react';
import { ShippingProgressBar } from './shipping-progress-bar';
import { ShippingBarSettings } from '@/shared/schema';

interface CartShippingBarProps {
  settings: ShippingBarSettings;
  cartTotal: number;
  onProductAdd?: (productId: string) => void;
}

export const CartShippingBar: React.FC<CartShippingBarProps> = (props) => {
  return (
    <div className="w-full mb-6">
      <ShippingProgressBar {...props} variant="cart" />
    </div>
  );
};
