
import React from 'react';
import { ShippingProgressBar } from './shipping-progress-bar';
import { ShippingBarSettings } from '@/shared/schema';

interface HeaderShippingBarProps {
  settings: ShippingBarSettings;
  cartTotal: number;
}

export const HeaderShippingBar: React.FC<HeaderShippingBarProps> = (props) => {
  return (
    <div className="w-full border-b" style={{ borderColor: props.settings.borderColor }}>
      <ShippingProgressBar {...props} variant="compact" />
    </div>
  );
};
