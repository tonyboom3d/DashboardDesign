import React, { useState, useEffect } from 'react';
import { useWixSettings } from '@/hooks/useWixSettings';
import { isInitialized as isWixApiClientInitialized, initWixApiClient } from '../lib/wix-api-client';

export default function SettingsManager() {
  const [retryCount, setRetryCount] = useState(0);
  const [isInitializing, setIsInitializing] = useState(true);

  // Use our custom hook to get settings
  const { settings, loading, error, updateSettings, fetchSettings } = useWixSettings();

  // Check if API client is initialized
  useEffect(() => {
    try {
      const isInitialized = isWixApiClientInitialized();
      setIsInitializing(!isInitialized);
      if (isInitialized) {
        fetchSettings();
      }
    } catch (err) {
      console.error("Error checking if WixApiClient is initialized:", err);
      setIsInitializing(true);
    }
  }, []);

  // Effect to retry loading settings if WixApiClient is initialized but settings aren't loaded
  useEffect(() => {
    const checkAndFetchSettings = () => {
      // If we have an error about initialization but WixApiClient is now initialized, retry
      if (error?.message?.includes("WixApiClient not initialized") && isWixApiClientInitialized()) {
        console.log("WixApiClient is now initialized, retrying settings fetch");
        fetchSettings();
      }
    };

    // Set up an interval to check and retry (limited number of times)
    const maxRetries = 3;
    if (retryCount < maxRetries && error && !settings) {
      const intervalId = setInterval(() => {
        setRetryCount(prev => prev + 1);
        checkAndFetchSettings();
      }, 1000); // Retry every second, up to maxRetries times

      return () => clearInterval(intervalId);
    }
  }, [error, retryCount, fetchSettings]);

  // Handle toggle enabled
  const handleToggleEnabled = async () => {
    if (!settings) return;

    const userSettings = settings.currentUserSettings;
    const newEnabledState = !userSettings.enabled;

    try {
      await updateSettings({ 
        enabled: newEnabledState
      });
    } catch (err) {
      console.error("Failed to update settings:", err);
    }
  };

  // Manual retry button handler
  const handleRetry = () => {
    console.log("Manually retrying to fetch settings");
    console.log("Current settings state:", settings);
    console.log("Is WixApiClient initialized:", isWixApiClientInitialized());
    fetchSettings();
  };

  // Show loading state
  if (loading) {
    return <div className="text-center py-10">טוען הגדרות...</div>;
  }

  // Show initializing state
  if (isInitializing) {
    return (
      <div className="text-center py-10">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto"></div>
        <div className="mt-4">מאתחל את המערכת...</div>
        <button 
          onClick={() => {
            try {
              // Always initialize with demo instance
              console.log("Initializing WixApiClient with demo instance");
              initWixApiClient('demo-instance-12345');
              console.log("WixApiClient initialized successfully");
              setIsInitializing(false);
              setTimeout(() => {
                fetchSettings();
              }, 100);
            } catch (err) {
              console.error("Failed to initialize manually:", err);
            }
          }}
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          המשך במצב דמו
        </button>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="text-center py-10 text-red-500">
        <div>שגיאה: {error.message}</div>
        <button 
          onClick={handleRetry} 
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          נסה שוב
        </button>
        <button 
          onClick={() => {
            try {
              // Always initialize with demo instance
              console.log("Initializing WixApiClient with demo instance from error state");
              initWixApiClient('demo-instance-12345');
              console.log("WixApiClient initialized successfully");
              setTimeout(() => {
                fetchSettings();
              }, 100);
            } catch (err) {
              console.error("Failed to initialize manually:", err);
            }
          }}
          className="mt-4 ml-2 px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
        >
          אפס והמשך במצב דמו
        </button>
      </div>
    );
  }

  // Show no settings state
  if (!settings || !settings.currentUserSettings) {
    return (
      <div className="text-center py-10">
        <div>לא נמצאו הגדרות עבור משתמש זה</div>
        <button 
          onClick={handleRetry} 
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded"
        >
          נסה שוב
        </button>
      </div>
    );
  }

  // Display settings
  const { currentUserSettings } = settings;

  return (
    <div className="space-y-6 bg-white p-6 rounded-lg shadow-md">
      <h1 className="text-2xl font-bold text-gray-800">הגדרות סרגל משלוח</h1>
      <div className="flex items-center justify-between p-4 bg-gray-50 rounded-md">
        <span className="font-medium text-gray-700">סטטוס:</span>
        <div className="flex items-center">
          <span className={`mr-2 ${currentUserSettings.enabled ? 'text-green-500' : 'text-red-500'}`}>
            {currentUserSettings.enabled ? 'פעיל' : 'לא פעיל'}
          </span>
          <button
            onClick={handleToggleEnabled}
            className={`px-4 py-2 rounded font-medium ${
              currentUserSettings.enabled
                ? 'bg-red-100 text-red-700 hover:bg-red-200'
                : 'bg-green-100 text-green-700 hover:bg-green-200'
            }`}
          >
            {currentUserSettings.enabled ? 'כבה' : 'הפעל'}
          </button>
        </div>
      </div>

      <div className="space-y-4 mt-4">
        <div className="p-4 bg-gray-50 rounded-md">
          <h2 className="font-medium text-gray-700 mb-2">מידע נוסף:</h2>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>תוכנית נוכחית:</div>
            <div className="font-semibold">{currentUserSettings.currentPlan}</div>

            <div>מספר צפיות:</div>
            <div className="font-semibold">{currentUserSettings.usage}</div>

            <div>תאריך איפוס:</div>
            <div className="font-semibold">
              {currentUserSettings.resetDate && new Date(currentUserSettings.resetDate).toLocaleDateString()}
            </div>
          </div>
        </div>

        {currentUserSettings.fullUserSettings && (
          <div className="p-4 bg-gray-50 rounded-md">
            <h2 className="font-medium text-gray-700 mb-2">הגדרות סרגל משלוח:</h2>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>סף למשלוח חינם:</div>
              <div className="font-semibold">{currentUserSettings.fullUserSettings.threshold} {currentUserSettings.fullUserSettings.currencySymbol}</div>

              <div>סגנון הסרגל:</div>
              <div className="font-semibold">{currentUserSettings.fullUserSettings.barStyle}</div>

              <div>צבע הסרגל:</div>
              <div className="flex items-center">
                <span className="w-4 h-4 mr-2 inline-block rounded" style={{backgroundColor: currentUserSettings.fullUserSettings.barColor}}></span>
                <span>{currentUserSettings.fullUserSettings.barColor}</span>
              </div>

              <div>הצג בעמוד מוצר:</div>
              <div className="font-semibold">{currentUserSettings.fullUserSettings.showOnProduct ? 'כן' : 'לא'}</div>

              <div>הצג בעגלה:</div>
              <div className="font-semibold">{currentUserSettings.fullUserSettings.showOnCart ? 'כן' : 'לא'}</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}