
import React from 'react';
import { ShippingProgressBar } from './shipping-progress-bar';
import { ShippingBarSettings } from '@/shared/schema';

interface MiniCartShippingBarProps {
  settings: ShippingBarSettings;
  cartTotal: number;
  onProductAdd?: (productId: string) => void;
}

export const MiniCartShippingBar: React.FC<MiniCartShippingBarProps> = (props) => {
  return (
    <div className="w-full border-t border-b" style={{ borderColor: props.settings.borderColor }}>
      <ShippingProgressBar {...props} variant="mini" />
    </div>
  );
};
