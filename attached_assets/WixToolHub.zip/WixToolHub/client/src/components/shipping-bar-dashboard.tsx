import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import ColorPicker from '@/components/ui/color-picker';
import ToggleSwitch from '@/components/ui/toggle-switch';
import IconPicker from '@/components/ui/icon-picker';
import EmojiPicker from '@/components/ui/emoji-picker';
import CurrencyPicker, { currencies } from '@/components/ui/currency-picker';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { ShippingBarSettings, WixProduct, SelectedProduct } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import ShippingBar from '@/components/ui/shipping-bar';
import { AlertTriangle, CreditCard, Eye, Power, Trophy, ShoppingCart as Shopping } from 'lucide-react';

const ShippingBarDashboard = () => {
  const { toast } = useToast();
  const [activePreview, setActivePreview] = useState<'mobile' | 'desktop'>('desktop');
  
  // Fetch settings data
  const { data: settings, isLoading: isSettingsLoading } = useQuery<ShippingBarSettings>({
    queryKey: ['/api/settings'],
  });
  
  // Fetch selected products
  const { data: selectedProducts, isLoading: isProductsLoading } = useQuery<SelectedProduct[]>({
    queryKey: ['/api/products'],
  });
  
  // Fetch available products for selection
  const { data: availableProducts, isLoading: isAvailableProductsLoading } = useQuery<WixProduct[]>({
    queryKey: ['/api/demo/products'],
  });
  
  // Local state for form
  const [formData, setFormData] = useState<Partial<ShippingBarSettings>>({
    threshold: "50",
    enabled: true,
    
    // Progress Bar Customization
    barStyle: "simple",
    barColor: "#4f46e5",
    progressBgColor: "#E0E0E0",
    
    // Background Bar Customization
    bgBarStyle: "simple",
    backgroundColor: "#F5F5F5",
    borderColor: "#E0E0E0",
    borderThickness: 0,
    
    // Text and Button Settings
    textColor: "#FFFFFF",
    accentColor: "#FF5722",
    buttonText: "Add",
    
    // Content Settings
    barText: "${remaining} away from FREE SHIPPING!",
    successText: "🎉 Congratulations! You qualify for FREE SHIPPING!",
    productSelectionMethod: "manual",
    maxSuggestions: 3,
    
    // Currency Settings
    currencyCode: "USD",
    currencySymbol: "$",
    
    // Layout & Positioning
    textDirection: "ltr",
    iconEmoji: "🎁",
    iconPosition: "before",
    position: "top",
    
    // Display Locations
    showOnProduct: true,
    showOnCart: true,
    showOnHeader: true,
    showOnMiniCart: true,
    
    // Device-specific Display Options
    showOnMobile: true,
    showOnDesktop: true,
    showOnMobileProduct: true,
    showOnMobileCart: true,
    showOnMobileHeader: true,
    showOnMobileMiniCart: true,
    showOnDesktopProduct: true,
    showOnDesktopCart: true,
    showOnDesktopHeader: true,
    showOnDesktopMiniCart: true
  });
  
  const [previewCartTotal, setPreviewCartTotal] = useState(30);
  
  // Update form data when settings are loaded
  useEffect(() => {
    if (settings) {
      setFormData(settings);
    }
  }, [settings]);
  
  // Save settings mutation
  const saveSettingsMutation = useMutation({
    mutationFn: async (data: Partial<ShippingBarSettings>) => {
      const response = await apiRequest('POST', '/api/settings', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
      toast({
        title: "Settings Saved",
        description: "Your shipping bar settings have been updated successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Error Saving Settings",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  // Remove product mutation
  const removeProductMutation = useMutation({
    mutationFn: async (productId: string) => {
      const response = await apiRequest('DELETE', `/api/products/${productId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({
        title: "Product Removed",
        description: "The product has been removed from your suggestions."
      });
    }
  });
  
  // Handle form field changes
  const handleInputChange = (name: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleCurrencyChange = (code: string, symbol: string) => {
    setFormData(prev => ({
      ...prev,
      currencyCode: code,
      currencySymbol: symbol
    }));
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveSettingsMutation.mutate(formData);
  };
  
  // Handle remove product
  const handleRemoveProduct = (productId: string) => {
    removeProductMutation.mutate(productId);
  };
  
  // Loading state
  if (isSettingsLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  const upgradeToPremium = () => {
    toast({
      title: "Upgrade to Premium",
      description: "This feature will be available soon. Please check for future updates.",
    });
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Free Shipping Bar Settings</h1>
          <p className="text-gray-500">Configure how the free shipping bar displays in your store</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="flex items-center space-x-2">
              <Switch
                id="toggle-app-status"
                checked={formData.enabled === true}
                onCheckedChange={(checked) => handleInputChange('enabled', checked)}
                className={formData.enabled ? "bg-blue-400 hover:bg-blue-500" : "bg-red-400 hover:bg-red-500"}
              />
              <Label htmlFor="toggle-app-status" className="text-sm font-medium text-gray-700 flex items-center gap-1">
                <Power className="h-3.5 w-3.5" />
                {formData.enabled ? "Enabled" : "Disabled"}
              </Label>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="flex items-center gap-1">
              <Eye className="h-3 w-3" />
              <span>{formData.viewCount || 0} Views</span>
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1">
              <Trophy className="h-3 w-3" />
              <span>Plan: {formData.plan === "free" ? "Free" : "Premium"}</span>
            </Badge>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <form onSubmit={handleSubmit}>
            <Accordion type="single" defaultValue="threshold" collapsible className="space-y-4">
              {/* Threshold Section */}
              <Card>
                <AccordionItem value="threshold" className="border-none">
                  <AccordionTrigger className="px-4 py-2 hover:bg-gray-50 rounded-t-lg">
                    <div className="flex items-center">
                      <CreditCard className="h-5 w-5 mr-2 text-primary" />
                      <span className="font-medium">Free Shipping Threshold</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pb-4 pt-2">
                    <p className="text-sm text-gray-500 mb-4">
                      Set the minimum amount customers need to reach to get free shipping
                    </p>
                    
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="shipping-threshold" className="text-sm font-medium text-gray-700">
                          Free Shipping Threshold
                        </Label>
                        <div className="mt-1 max-w-lg flex rounded-md shadow-sm">
                          <Select 
                            value={formData.currencyCode || "USD"} 
                            onValueChange={(code) => {
                              const currency = currencies.find((c: {code: string, symbol: string}) => c.code === code);
                              if (currency) {
                                handleCurrencyChange(currency.code, currency.symbol);
                              }
                            }}
                          >
                            <SelectTrigger 
                              id="currency-selector"
                              className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm w-auto"
                            >
                              <div className="flex items-center cursor-pointer">
                                <span>{formData.currencySymbol || "$"}</span>
                                <svg className="ml-1 h-4 w-4 text-gray-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                  <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                                </svg>
                              </div>
                            </SelectTrigger>
                            <SelectContent>
                              {currencies.map((currency: {code: string, symbol: string, name: string}) => (
                                <SelectItem key={currency.code} value={currency.code}>
                                  <div className="flex items-center">
                                    <span className="mr-2">{currency.symbol}</span>
                                    <span>{currency.name}</span>
                                    <span className="ml-2 text-gray-500">({currency.code})</span>
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Input
                            type="number"
                            step="0.01"
                            id="shipping-threshold"
                            name="threshold"
                            value={formData.threshold}
                            onChange={(e) => handleInputChange('threshold', e.target.value)}
                            className="rounded-l-none"
                          />
                        </div>
                        <p className="mt-2 text-sm text-gray-500">
                          Minimum cart amount required to qualify for free shipping
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Card>

              {/* Appearance Section */}
              <Card>
                <AccordionItem value="appearance" className="border-none">
                  <AccordionTrigger className="px-4 py-2 hover:bg-gray-50 rounded-t-lg">
                    <div className="flex items-center">
                      <span className="h-5 w-5 mr-2 text-primary flex justify-center items-center">🎨</span>
                      <span className="font-medium">Appearance</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pb-4 pt-2">
                    <p className="text-sm text-gray-500 mb-4">
                      Customize the appearance of your free shipping bar
                    </p>
                    
                    <div className="space-y-6">
                      {/* Progress Bar Section */}
                      <div className="border border-gray-200 rounded-md p-4 space-y-4">
                        <h3 className="font-medium text-gray-800">Progress Bar</h3>
                        
                        <div>
                          <Label className="text-sm font-medium text-gray-700">
                            Progress Bar Style
                          </Label>
                          <RadioGroup 
                            value={formData.barStyle} 
                            onValueChange={(value) => handleInputChange('barStyle', value)}
                            className="mt-2 space-y-2"
                          >
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="simple" id="bar-style-simple" />
                              <Label htmlFor="bar-style-simple">Simple Bar</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="gradient" id="bar-style-gradient" />
                              <Label htmlFor="bar-style-gradient">Gradient Bar</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="animated" id="bar-style-animated" />
                              <Label htmlFor="bar-style-animated">Animated Bar</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="none" id="bar-style-none" />
                              <Label htmlFor="bar-style-none">No Bar</Label>
                            </div>
                          </RadioGroup>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <ColorPicker
                            id="bar-color"
                            label="Progress Bar Color"
                            value={formData.barColor || '#4f46e5'}
                            onChange={(value) => handleInputChange('barColor', value)}
                          />
                          <ColorPicker
                            id="progress-bg-color"
                            label="Progress Container Color"
                            value={formData.progressBgColor || '#E0E0E0'}
                            onChange={(value) => handleInputChange('progressBgColor', value)}
                          />
                        </div>
                      </div>

                      {/* Background Bar Section */}
                      <div className="border border-gray-200 rounded-md p-4 space-y-4">
                        <h3 className="font-medium text-gray-800">Background Bar</h3>
                        
                        <div>
                          <Label className="text-sm font-medium text-gray-700">
                            Background Style
                          </Label>
                          <RadioGroup 
                            value={formData.bgBarStyle} 
                            onValueChange={(value) => handleInputChange('bgBarStyle', value)}
                            className="mt-2 space-y-2"
                          >
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="simple" id="bg-style-simple" />
                              <Label htmlFor="bg-style-simple">Simple Background</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="gradient" id="bg-style-gradient" />
                              <Label htmlFor="bg-style-gradient">Gradient Background</Label>
                            </div>
                          </RadioGroup>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <ColorPicker
                            id="background-color"
                            label="Background Color"
                            value={formData.backgroundColor || '#F5F5F5'}
                            onChange={(value) => handleInputChange('backgroundColor', value)}
                          />
                          <ColorPicker
                            id="border-color"
                            label="Border Color"
                            value={formData.borderColor || '#E0E0E0'}
                            onChange={(value) => handleInputChange('borderColor', value)}
                          />
                        </div>

                        <div>
                          <Label htmlFor="border-thickness" className="text-sm font-medium text-gray-700">
                            Border Thickness
                          </Label>
                          <Input
                            type="number"
                            id="border-thickness"
                            name="borderThickness"
                            min="0"
                            max="10"
                            value={formData.borderThickness}
                            onChange={(e) => handleInputChange('borderThickness', parseInt(e.target.value))}
                            className="max-w-[100px] mt-2"
                          />
                        </div>
                      </div>

                      {/* Text and Button Settings */}
                      <div className="border border-gray-200 rounded-md p-4 space-y-4">
                        <h3 className="font-medium text-gray-800">Text & Button Settings</h3>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <ColorPicker
                            id="text-color"
                            label="Text Color"
                            value={formData.textColor || '#FFFFFF'}
                            onChange={(value) => handleInputChange('textColor', value)}
                          />
                          <ColorPicker
                            id="accent-color"
                            label="Accent Color"
                            value={formData.accentColor || '#FF5722'}
                            onChange={(value) => handleInputChange('accentColor', value)}
                          />
                        </div>

                        <div>
                          <Label htmlFor="button-text" className="text-sm font-medium text-gray-700">
                            Button Text
                          </Label>
                          <Input
                            type="text"
                            id="button-text"
                            name="buttonText"
                            value={formData.buttonText}
                            onChange={(e) => handleInputChange('buttonText', e.target.value)}
                            placeholder="Add"
                            className="max-w-[200px] mt-2"
                          />
                        </div>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Card>

              {/* Content Section */}
              <Card>
                <AccordionItem value="content" className="border-none">
                  <AccordionTrigger className="px-4 py-2 hover:bg-gray-50 rounded-t-lg">
                    <div className="flex items-center">
                      <span className="h-5 w-5 mr-2 text-primary flex justify-center items-center">📝</span>
                      <span className="font-medium">Content</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pb-4 pt-2">
                    <p className="text-sm text-gray-500 mb-4">
                      Customize the text and content of your free shipping bar
                    </p>
                    
                    <div className="space-y-6">
                      <div>
                        <Label htmlFor="bar-text" className="text-sm font-medium text-gray-700">
                          Progress Bar Text
                        </Label>
                        <p className="text-xs text-gray-500 mb-2">Use ${"{remaining}"} as a placeholder for the remaining amount</p>
                        <Textarea
                          id="bar-text"
                          name="barText"
                          value={formData.barText || ''}
                          onChange={(e) => handleInputChange('barText', e.target.value)}
                          placeholder="${remaining} away from FREE SHIPPING!"
                          className="resize-none mt-1"
                        />
                      </div>

                      <div>
                        <Label htmlFor="success-text" className="text-sm font-medium text-gray-700">
                          Success Message
                        </Label>
                        <p className="text-xs text-gray-500 mb-2">Displayed when the customer meets the free shipping threshold</p>
                        <Textarea
                          id="success-text"
                          name="successText"
                          value={formData.successText || ''}
                          onChange={(e) => handleInputChange('successText', e.target.value)}
                          placeholder="🎉 Congratulations! You qualify for FREE SHIPPING!"
                          className="resize-none mt-1"
                        />
                      </div>

                      <div>
                        <Label className="text-sm font-medium text-gray-700 mb-2 block">
                          Product Selection Method
                        </Label>
                        <RadioGroup 
                          value={formData.productSelectionMethod} 
                          onValueChange={(value) => handleInputChange('productSelectionMethod', value)}
                          className="space-y-2"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="manual" id="method-manual" />
                            <Label htmlFor="method-manual">Manual Selection</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="auto" id="method-auto" />
                            <Label htmlFor="method-auto">Automatic (AI-based)</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="recent" id="method-recent" />
                            <Label htmlFor="method-recent">Recently Viewed</Label>
                          </div>
                        </RadioGroup>
                      </div>

                      <div>
                        <Label htmlFor="max-suggestions" className="text-sm font-medium text-gray-700">
                          Maximum Products to Show
                        </Label>
                        <Select
                          value={String(formData.maxSuggestions)}
                          onValueChange={(value) => handleInputChange('maxSuggestions', parseInt(value))}
                        >
                          <SelectTrigger className="max-w-[100px] mt-2">
                            <SelectValue placeholder="3" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">1</SelectItem>
                            <SelectItem value="2">2</SelectItem>
                            <SelectItem value="3">3</SelectItem>
                            <SelectItem value="4">4</SelectItem>
                            <SelectItem value="5">5</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <EmojiPicker
                          id="icon-emoji"
                          label="Icon (Emoji)"
                          value={formData.iconEmoji || ''}
                          onChange={(value) => handleInputChange('iconEmoji', value)}
                        />
                      </div>

                      <div>
                        <Label className="text-sm font-medium text-gray-700 mb-2 block">
                          Icon Position
                        </Label>
                        <RadioGroup 
                          value={formData.iconPosition} 
                          onValueChange={(value) => handleInputChange('iconPosition', value)}
                          className="space-y-2"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="before" id="icon-before" />
                            <Label htmlFor="icon-before">Before Text</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="after" id="icon-after" />
                            <Label htmlFor="icon-after">After Text</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="none" id="icon-none" />
                            <Label htmlFor="icon-none">No Icon</Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Card>

              {/* Layout & Positioning Section */}
              <Card>
                <AccordionItem value="layout" className="border-none">
                  <AccordionTrigger className="px-4 py-2 hover:bg-gray-50 rounded-t-lg">
                    <div className="flex items-center">
                      <span className="h-5 w-5 mr-2 text-primary flex justify-center items-center">📐</span>
                      <span className="font-medium">Layout & Positioning</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pb-4 pt-2">
                    <p className="text-sm text-gray-500 mb-4">
                      Configure how your free shipping bar is positioned
                    </p>
                    
                    <div className="space-y-6">
                      <div>
                        <Label className="text-sm font-medium text-gray-700 mb-2 block">
                          Text Direction
                        </Label>
                        <RadioGroup 
                          value={formData.textDirection} 
                          onValueChange={(value) => handleInputChange('textDirection', value)}
                          className="space-y-2"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="ltr" id="dir-ltr" />
                            <Label htmlFor="dir-ltr">Left to Right (LTR)</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="rtl" id="dir-rtl" />
                            <Label htmlFor="dir-rtl">Right to Left (RTL)</Label>
                          </div>
                        </RadioGroup>
                      </div>

                      <div>
                        <Label className="text-sm font-medium text-gray-700 mb-2 block">
                          Bar Position
                        </Label>
                        <RadioGroup 
                          value={formData.position} 
                          onValueChange={(value) => handleInputChange('position', value)}
                          className="space-y-2"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="top" id="pos-top" />
                            <Label htmlFor="pos-top">Top</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="bottom" id="pos-bottom" />
                            <Label htmlFor="pos-bottom">Bottom</Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Card>

              {/* Display Locations Section */}
              <Card>
                <AccordionItem value="display" className="border-none">
                  <AccordionTrigger className="px-4 py-2 hover:bg-gray-50 rounded-t-lg">
                    <div className="flex items-center">
                      <span className="h-5 w-5 mr-2 text-primary flex justify-center items-center">📱</span>
                      <span className="font-medium">Display Locations</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pb-4 pt-2">
                    <p className="text-sm text-gray-500 mb-4">
                      Choose where to display the free shipping bar in your store
                    </p>
                    
                    {/* Global Device Controls */}
                    <div className="mb-6">
                      <h3 className="text-sm font-medium text-gray-800 mb-3">Global Device Visibility</h3>
                      <div className="flex items-center gap-6 p-4 bg-blue-50 border border-blue-100 rounded-lg">
                        <div className="flex items-center gap-3">
                          <Checkbox 
                            id="show-on-mobile"
                            checked={formData.showOnMobile === true}
                            onCheckedChange={(checked) => handleInputChange('showOnMobile', checked === true)}
                            className="data-[state=checked]:bg-blue-600 data-[state=checked]:text-white"
                          />
                          <div className="flex items-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <rect x="5" y="2" width="14" height="20" rx="2" ry="2" />
                              <line x1="12" y1="18" x2="12" y2="18" />
                            </svg>
                            <Label htmlFor="show-on-mobile" className="text-sm font-medium text-gray-700">
                              Show on Mobile
                            </Label>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Checkbox 
                            id="show-on-desktop"
                            checked={formData.showOnDesktop === true}
                            onCheckedChange={(checked) => handleInputChange('showOnDesktop', checked === true)}
                            className="data-[state=checked]:bg-blue-600 data-[state=checked]:text-white"
                          />
                          <div className="flex items-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
                              <line x1="8" y1="21" x2="16" y2="21" />
                              <line x1="12" y1="17" x2="12" y2="21" />
                            </svg>
                            <Label htmlFor="show-on-desktop" className="text-sm font-medium text-gray-700">
                              Show on Desktop
                            </Label>
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">These settings control the overall visibility of your shipping bar on different device types.</p>
                    </div>

                    {/* Page-Specific Locations */}
                    <div className="space-y-4">
                      <h3 className="text-sm font-medium text-gray-800">Page-Specific Locations</h3>
                      <div className="grid gap-4">
                        {/* Product Page */}
                        <div className="border border-gray-200 rounded-md p-4">
                          <div className="flex items-center gap-3 mb-3">
                            <Checkbox 
                              id="location-product"
                              checked={formData.showOnProduct === true}
                              onCheckedChange={(checked) => handleInputChange('showOnProduct', checked === true)}
                              className="data-[state=checked]:bg-indigo-600"
                            />
                            <Label htmlFor="location-product" className="text-sm font-medium text-gray-800 flex items-center gap-2">
                              <Shopping className="h-4 w-4 text-indigo-600" />
                              Product Page
                            </Label>
                          </div>
                          <div className="ml-8 flex gap-6">
                            <div className="flex items-center gap-2">
                              <Checkbox 
                                id="location-product-mobile"
                                checked={formData.showOnMobileProduct === true}
                                onCheckedChange={(checked) => handleInputChange('showOnMobileProduct', checked === true)}
                                disabled={!formData.showOnProduct}
                                className={formData.showOnProduct ? "data-[state=checked]:bg-indigo-500/80" : ""}
                              />
                              <Label htmlFor="location-product-mobile" className="text-xs text-gray-700 flex items-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <rect x="5" y="2" width="14" height="20" rx="2" ry="2" />
                                  <line x1="12" y1="18" x2="12" y2="18" />
                                </svg>
                                Mobile
                              </Label>
                            </div>
                            <div className="flex items-center gap-2">
                              <Checkbox 
                                id="location-product-desktop"
                                checked={formData.showOnDesktopProduct === true}
                                onCheckedChange={(checked) => handleInputChange('showOnDesktopProduct', checked === true)}
                                disabled={!formData.showOnProduct}
                                className={formData.showOnProduct ? "data-[state=checked]:bg-indigo-500/80" : ""}
                              />
                              <Label htmlFor="location-product-desktop" className="text-xs text-gray-700 flex items-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
                                  <line x1="8" y1="21" x2="16" y2="21" />
                                  <line x1="12" y1="17" x2="12" y2="21" />
                                </svg>
                                Desktop
                              </Label>
                            </div>
                          </div>
                        </div>

                        {/* Cart Page */}
                        <div className="border border-gray-200 rounded-md p-4">
                          <div className="flex items-center gap-3 mb-3">
                            <Checkbox 
                              id="location-cart"
                              checked={formData.showOnCart === true}
                              onCheckedChange={(checked) => handleInputChange('showOnCart', checked === true)}
                              className="data-[state=checked]:bg-indigo-600"
                            />
                            <Label htmlFor="location-cart" className="text-sm font-medium text-gray-800 flex items-center gap-2">
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <circle cx="9" cy="21" r="1" />
                                <circle cx="20" cy="21" r="1" />
                                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                              </svg>
                              Cart Page
                            </Label>
                          </div>
                          <div className="ml-8 flex gap-6">
                            <div className="flex items-center gap-2">
                              <Checkbox 
                                id="location-cart-mobile"
                                checked={formData.showOnMobileCart === true}
                                onCheckedChange={(checked) => handleInputChange('showOnMobileCart', checked === true)}
                                disabled={!formData.showOnCart}
                                className={formData.showOnCart ? "data-[state=checked]:bg-indigo-500/80" : ""}
                              />
                              <Label htmlFor="location-cart-mobile" className="text-xs text-gray-700 flex items-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <rect x="5" y="2" width="14" height="20" rx="2" ry="2" />
                                  <line x1="12" y1="18" x2="12" y2="18" />
                                </svg>
                                Mobile
                              </Label>
                            </div>
                            <div className="flex items-center gap-2">
                              <Checkbox 
                                id="location-cart-desktop"
                                checked={formData.showOnDesktopCart === true}
                                onCheckedChange={(checked) => handleInputChange('showOnDesktopCart', checked === true)}
                                disabled={!formData.showOnCart}
                                className={formData.showOnCart ? "data-[state=checked]:bg-indigo-500/80" : ""}
                              />
                              <Label htmlFor="location-cart-desktop" className="text-xs text-gray-700 flex items-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
                                  <line x1="8" y1="21" x2="16" y2="21" />
                                  <line x1="12" y1="17" x2="12" y2="21" />
                                </svg>
                                Desktop
                              </Label>
                            </div>
                          </div>
                        </div>

                        {/* Site Header */}
                        <div className="border border-gray-200 rounded-md p-4">
                          <div className="flex items-center gap-3 mb-3">
                            <Checkbox 
                              id="location-header"
                              checked={formData.showOnHeader === true}
                              onCheckedChange={(checked) => handleInputChange('showOnHeader', checked === true)}
                              className="data-[state=checked]:bg-indigo-600"
                            />
                            <Label htmlFor="location-header" className="text-sm font-medium text-gray-800 flex items-center gap-2">
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <line x1="3" y1="12" x2="21" y2="12" />
                                <line x1="3" y1="6" x2="21" y2="6" />
                                <line x1="3" y1="18" x2="21" y2="18" />
                              </svg>
                              Site Header
                            </Label>
                          </div>
                          <div className="ml-8 flex gap-6">
                            <div className="flex items-center gap-2">
                              <Checkbox 
                                id="location-header-mobile"
                                checked={formData.showOnMobileHeader === true}
                                onCheckedChange={(checked) => handleInputChange('showOnMobileHeader', checked === true)}
                                disabled={!formData.showOnHeader}
                                className={formData.showOnHeader ? "data-[state=checked]:bg-indigo-500/80" : ""}
                              />
                              <Label htmlFor="location-header-mobile" className="text-xs text-gray-700 flex items-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <rect x="5" y="2" width="14" height="20" rx="2" ry="2" />
                                  <line x1="12" y1="18" x2="12" y2="18" />
                                </svg>
                                Mobile
                              </Label>
                            </div>
                            <div className="flex items-center gap-2">
                              <Checkbox 
                                id="location-header-desktop"
                                checked={formData.showOnDesktopHeader === true}
                                onCheckedChange={(checked) => handleInputChange('showOnDesktopHeader', checked === true)}
                                disabled={!formData.showOnHeader}
                                className={formData.showOnHeader ? "data-[state=checked]:bg-indigo-500/80" : ""}
                              />
                              <Label htmlFor="location-header-desktop" className="text-xs text-gray-700 flex items-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
                                  <line x1="8" y1="21" x2="16" y2="21" />
                                  <line x1="12" y1="17" x2="12" y2="21" />
                                </svg>
                                Desktop
                              </Label>
                            </div>
                          </div>
                        </div>

                        {/* Mini-Cart */}
                        <div className="border border-gray-200 rounded-md p-4">
                          <div className="flex items-center gap-3 mb-3">
                            <Checkbox 
                              id="location-mini"
                              checked={formData.showOnMiniCart === true}
                              onCheckedChange={(checked) => handleInputChange('showOnMiniCart', checked === true)}
                              className="data-[state=checked]:bg-indigo-600"
                            />
                            <Label htmlFor="location-mini" className="text-sm font-medium text-gray-800 flex items-center gap-2">
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <circle cx="9" cy="21" r="1" />
                                <circle cx="20" cy="21" r="1" />
                                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                              </svg>
                              Mini-Cart
                            </Label>
                          </div>
                          <div className="ml-8 flex gap-6">
                            <div className="flex items-center gap-2">
                              <Checkbox 
                                id="location-mini-mobile"
                                checked={formData.showOnMobileMiniCart === true}
                                onCheckedChange={(checked) => handleInputChange('showOnMobileMiniCart', checked === true)}
                                disabled={!formData.showOnMiniCart}
                                className={formData.showOnMiniCart ? "data-[state=checked]:bg-indigo-500/80" : ""}
                              />
                              <Label htmlFor="location-mini-mobile" className="text-xs text-gray-700 flex items-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <rect x="5" y="2" width="14" height="20" rx="2" ry="2" />
                                  <line x1="12" y1="18" x2="12" y2="18" />
                                </svg>
                                Mobile
                              </Label>
                            </div>
                            <div className="flex items-center gap-2">
                              <Checkbox 
                                id="location-mini-desktop"
                                checked={formData.showOnDesktopMiniCart === true}
                                onCheckedChange={(checked) => handleInputChange('showOnDesktopMiniCart', checked === true)}
                                disabled={!formData.showOnMiniCart}
                                className={formData.showOnMiniCart ? "data-[state=checked]:bg-indigo-500/80" : ""}
                              />
                              <Label htmlFor="location-mini-desktop" className="text-xs text-gray-700 flex items-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
                                  <line x1="8" y1="21" x2="16" y2="21" />
                                  <line x1="12" y1="17" x2="12" y2="21" />
                                </svg>
                                Desktop
                              </Label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Card>
            </Accordion>

            <div className="mt-6 flex gap-3 justify-end">
              <Button
                type="button"
                variant="outline"
                className="flex items-center gap-2 bg-purple-100 text-purple-700 hover:bg-purple-200 border-purple-300"
                onClick={upgradeToPremium}
              >
                <Trophy className="h-4 w-4" />
                Upgrade to Premium
              </Button>
              <Button 
                type="submit" 
                disabled={saveSettingsMutation.isPending}
                className="flex items-center gap-2"
              >
                {saveSettingsMutation.isPending ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent"></div>
                    Saving...
                  </>
                ) : (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    Save Settings
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>

        <div className="md:col-span-1">
          <Card className="sticky top-6">
            <div className="p-4 border-b border-gray-200 bg-gray-100">
              <h3 className="text-lg font-medium text-gray-900">Preview</h3>
              <p className="text-sm text-gray-600">Here's how your shipping bar will look</p>
            </div>
            <div className="p-4 space-y-4">
              <div className="flex justify-center space-x-4 mb-4">
                <Button 
                  variant={activePreview === 'desktop' ? 'default' : 'outline'} 
                  size="sm"
                  onClick={() => setActivePreview('desktop')}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  Desktop
                </Button>
                <Button 
                  variant={activePreview === 'mobile' ? 'default' : 'outline'} 
                  size="sm"
                  onClick={() => setActivePreview('mobile')}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                  Mobile
                </Button>
              </div>

              <div className={`border border-gray-200 rounded-md mx-auto ${activePreview === 'mobile' ? 'w-64' : 'w-full'}`}>
                <div className="p-3 bg-gray-100 border-b border-gray-200 flex justify-between items-center">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 rounded-full bg-gray-400"></div>
                    <div className="w-2 h-2 rounded-full bg-gray-400"></div>
                    <div className="w-2 h-2 rounded-full bg-gray-400"></div>
                  </div>
                  {activePreview === 'mobile' && (
                    <div className="w-20 h-1 rounded-full bg-gray-300"></div>
                  )}
                </div>
                <div className="p-4">
                  <div className="mb-4">
                    <ShippingBar 
                      settings={formData as ShippingBarSettings} 
                      cartTotal={previewCartTotal}
                      products={availableProducts?.slice(0, formData.maxSuggestions)}
                      variant={activePreview === 'mobile' ? 'mini' : 'default'}
                    />
                  </div>
                  
                  <div className="mt-6 space-y-4">
                    <h4 className="text-sm font-medium text-gray-700">Test with cart total:</h4>
                    <div className="flex items-center gap-2">
                      <Input 
                        type="range" 
                        min="0" 
                        max="400" 
                        step="1"
                        value={previewCartTotal} 
                        onChange={(e) => setPreviewCartTotal(parseFloat(e.target.value))}
                        className="w-full"
                      />
                      <div className="text-sm font-medium flex items-center">
                        <span>{formData.currencySymbol}</span>
                        <Input 
                          type="number"
                          value={previewCartTotal}
                          onChange={(e) => setPreviewCartTotal(parseFloat(e.target.value))}
                          className="w-16 ml-1"
                        />
                      </div>
                    </div>
                  </div>

                  {selectedProducts && selectedProducts.length > 0 ? (
                    <div className="mt-6">
                      <h4 className="text-sm font-medium text-gray-700 mb-3">Selected Products:</h4>
                      <div className="space-y-3">
                        {selectedProducts.map((product) => (
                          <div key={product.productId} className="flex justify-between items-center p-2 border border-gray-200 rounded-md">
                            <div className="flex items-center gap-2">
                              <div className="w-8 h-8 bg-gray-200 rounded-md flex items-center justify-center text-gray-500 text-xs">
                                {product.imageUrl ? (
                                  <img src={product.imageUrl} alt={product.title} className="w-8 h-8 object-cover rounded-md" />
                                ) : (
                                  <span>IMG</span>
                                )}
                              </div>
                              <div>
                                <p className="text-xs font-medium text-gray-800">{product.title}</p>
                                <p className="text-xs text-gray-500">{formData.currencySymbol}{product.price}</p>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemoveProduct(product.productId)}
                              className="h-6 w-6 p-0 rounded-full"
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                              </svg>
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="mt-6 p-4 border border-dashed border-gray-300 rounded-md bg-gray-50 text-center">
                      <p className="text-sm text-gray-500">No products selected for suggestions.</p>
                      <p className="text-xs text-gray-400 mt-1">Select products to display as suggestions.</p>
                    </div>
                  )}

                  {availableProducts && formData.productSelectionMethod === 'manual' && (
                    <div className="mt-6">
                      <h4 className="text-sm font-medium text-gray-700 mb-3">Available Products:</h4>
                      <div className="max-h-60 overflow-y-auto pr-2 space-y-2">
                        {availableProducts
                          .filter(product => !selectedProducts?.some(sp => sp.productId === product.id))
                          .map((product) => (
                            <div 
                              key={product.id}
                              className="flex justify-between items-center p-2 hover:bg-gray-50 border border-gray-200 rounded-md cursor-pointer"
                              onClick={() => {
                                // Add product to selections
                                const newProduct = {
                                  merchantId: "demo",
                                  productId: product.id,
                                  title: product.title,
                                  price: product.price,
                                  imageUrl: product.imageUrl
                                };
                                
                                apiRequest('POST', '/api/products', newProduct)
                                  .then(() => {
                                    queryClient.invalidateQueries({ queryKey: ['/api/products'] });
                                    toast({
                                      title: "Product Added",
                                      description: `${product.title} has been added to your suggestions.`
                                    });
                                  })
                                  .catch(error => {
                                    toast({
                                      title: "Error Adding Product",
                                      description: error.message,
                                      variant: "destructive"
                                    });
                                  });
                              }}
                            >
                              <div className="flex items-center gap-2">
                                <div className="w-8 h-8 bg-gray-200 rounded-md flex items-center justify-center text-gray-500 text-xs">
                                  {product.imageUrl ? (
                                    <img src={product.imageUrl} alt={product.title} className="w-8 h-8 object-cover rounded-md" />
                                  ) : (
                                    <span>IMG</span>
                                  )}
                                </div>
                                <div>
                                  <p className="text-xs font-medium text-gray-800">{product.title}</p>
                                  <p className="text-xs text-gray-500">{formData.currencySymbol}{product.price}</p>
                                </div>
                              </div>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                className="h-7 px-2 text-xs bg-gray-100"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                                </svg>
                                Add
                              </Button>
                            </div>
                          ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ShippingBarDashboard;