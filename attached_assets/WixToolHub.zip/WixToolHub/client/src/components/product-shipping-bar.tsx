
import React from 'react';
import { ShippingProgressBar } from './shipping-progress-bar';
import { ShippingBarSettings } from '@/shared/schema';

interface ProductShippingBarProps {
  settings: ShippingBarSettings;
  cartTotal: number;
  onProductAdd?: (productId: string) => void;
}

export const ProductShippingBar: React.FC<ProductShippingBarProps> = (props) => {
  return (
    <div className="max-w-4xl mx-auto my-4">
      <ShippingProgressBar {...props} variant="default" />
    </div>
  );
};
