
import React from 'react';
import { Progress } from './ui/progress';
import { ShippingBarSettings } from '@/shared/schema';

interface ShippingProgressBarProps {
  settings: ShippingBarSettings;
  cartTotal: number;
  variant?: 'default' | 'compact' | 'mini' | 'cart';
  onProductAdd?: (productId: string) => void;
}

export const ShippingProgressBar: React.FC<ShippingProgressBarProps> = ({
  settings,
  cartTotal,
  variant = 'default',
  onProductAdd
}) => {
  const threshold = parseFloat(settings.threshold);
  const progress = Math.min((cartTotal / threshold) * 100, 100);
  const remaining = Math.max(threshold - cartTotal, 0);
  
  const variantStyles = {
    default: 'p-4',
    compact: 'p-2 text-sm',
    mini: 'p-2 text-xs',
    cart: 'p-6'
  };

  const barText = remaining > 0 
    ? settings.barText.replace('${remaining}', `${settings.currencySymbol}${remaining.toFixed(2)}`)
    : settings.successText;

  return (
    <div 
      className={`w-full ${variantStyles[variant]} rounded-lg`}
      style={{ backgroundColor: settings.backgroundColor }}
    >
      <div className="flex flex-col gap-2">
        <div 
          className="text-center"
          style={{ color: settings.textColor }}
        >
          {barText}
        </div>
        
        <Progress
          value={progress}
          className="h-2"
          indicatorColor={settings.barColor}
          backgroundColor={settings.progressBgColor}
        />
      </div>
    </div>
  );
};
