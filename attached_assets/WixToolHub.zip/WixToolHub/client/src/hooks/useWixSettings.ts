import { useState, useEffect } from 'react';
import { getWixApiClient } from '../lib/wix-api-client';
import { ShippingBarSettings } from '@shared/schema';
import { getDemoSettings } from '../lib/demo-settings';

export function useWixSettings() {
  const [settings, setSettings] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);
  const [updating, setUpdating] = useState<boolean>(false);

  const fetchSettings = async () => {
    setLoading(true);
    try {
      console.log("useWixSettings: Fetching user settings...");
      console.log("Current settings before fetch:", settings);

      // Check if we can extract settings from the demo data in case of Wix dashboard
      try {
        const demoSettings = window.parent && window.parent.location && 
                           window.parent.location.href.includes('wix.com') ? 
                           getDemoSettings() : null;
        
        if (demoSettings) {
          console.log("Using demo settings for Wix dashboard:", demoSettings);
          setSettings(demoSettings);
          setError(null);
          setLoading(false);
          return;
        }
      } catch (demoErr) {
        console.log("Error getting demo settings:", demoErr);
      }

      const data = await getWixApiClient().getUserSettings();
      console.log("useWixSettings: Received data:", data);

      if (data && data.error) {
        console.log("Settings not found:", data.error);
        setSettings(null);
        setError(new Error(data.error));
      } else {
        console.log("Setting state with fetched settings:", data);
        setSettings(data);
        setError(null);
      }
    } catch (err) {
      console.error("Error fetching settings:", err);
      setError(err instanceof Error ? err : new Error(String(err)));

      // Adding more detailed error information to help troubleshoot
      console.error("Error details:", {
        message: err instanceof Error ? err.message : String(err),
        stack: err instanceof Error ? err.stack : 'No stack trace available'
      });
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = async (newSettings: Partial<ShippingBarSettings>) => {
    setUpdating(true);
    try {
      console.log("Updating settings:", newSettings);
      const result = await getWixApiClient().updateSettings(newSettings);

      // Update local state after successful API call
      setSettings(prev => {
        if (!prev) return result;

        return {
          ...prev,
          currentUserSettings: {
            ...prev.currentUserSettings,
            ...newSettings,
            fullUserSettings: {
              ...prev.currentUserSettings.fullUserSettings,
              ...newSettings
            }
          }
        };
      });

      return result;
    } catch (err) {
      console.error("Error updating settings:", err);
      setError(err instanceof Error ? err : new Error(String(err)));
      return false;
    } finally {
      setUpdating(false);
    }
  };

  // Initialize on component mount
  useEffect(() => {
    fetchSettings();
  }, []);

  return {
    settings,
    loading,
    error,
    fetchSettings,
    updateSettings,
    updating
  };
}