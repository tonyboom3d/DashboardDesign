import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ShippingBarSettings, WixProduct } from '@shared/schema';

interface UseShippingBarProps {
  cartTotal: number;
  merchantId?: string;
}

interface UseShippingBarResult {
  settings: ShippingBarSettings | undefined;
  remainingAmount: number;
  isQualified: boolean;
  progress: number;
  suggestedProducts: WixProduct[] | undefined;
  isLoading: boolean;
  error: Error | null;
}

export const useShippingBar = ({
  cartTotal,
  merchantId = 'demo-merchant'
}: UseShippingBarProps): UseShippingBarResult => {
  const [remainingAmount, setRemainingAmount] = useState(0);
  const [isQualified, setIsQualified] = useState(false);
  const [progress, setProgress] = useState(0);
  const [suggestedProducts, setSuggestedProducts] = useState<WixProduct[] | undefined>(undefined);
  
  // Fetch settings
  const { 
    data: settings,
    isLoading: isSettingsLoading,
    error: settingsError
  } = useQuery<ShippingBarSettings>({
    queryKey: [`/api/settings?merchantId=${merchantId}`],
  });
  
  // Fetch available products for suggestions
  const {
    data: products,
    isLoading: isProductsLoading,
    error: productsError
  } = useQuery<WixProduct[]>({
    queryKey: ['/api/demo/products'],
    enabled: !!settings, // Only fetch products if settings are loaded
  });
  
  useEffect(() => {
    if (settings) {
      const threshold = parseFloat(settings.threshold.toString());
      const remaining = Math.max(threshold - cartTotal, 0);
      const progressPercent = Math.min((cartTotal / threshold) * 100, 100);
      
      setRemainingAmount(remaining);
      setIsQualified(cartTotal >= threshold);
      setProgress(progressPercent);
      
      // Filter suggested products based on remaining amount
      if (products) {
        const filtered = products
          .filter(product => product.price <= remaining)
          .slice(0, settings.maxSuggestions);
        
        setSuggestedProducts(filtered);
      }
    }
  }, [settings, cartTotal, products]);
  
  return {
    settings,
    remainingAmount,
    isQualified,
    progress,
    suggestedProducts,
    isLoading: isSettingsLoading || isProductsLoading,
    error: settingsError || productsError
  };
};
